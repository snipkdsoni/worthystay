# fix_user.py
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from django.contrib.auth import get_user_model

User = get_user_model()

# First, delete all admin users
User.objects.filter(email='admin@example.com').delete()
print("Removed all existing admin users")

# Now create a fresh admin user
admin = User.objects.create_user(
    email='admin@example.com',
    password='admin123',
    first_name='Admin',
    last_name='User'
)
admin.is_staff = True
admin.is_superuser = True
admin.is_active = True
admin.save()

print("\nNew admin user created successfully!")
print("You can now log in with:")
print("Email: admin@example.com")
print("Password: admin123")