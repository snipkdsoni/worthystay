// Initialize any global functionality
document.addEventListener('DOMContentLoaded', () => {
    // Global initialization code can go here
    console.log('WorthyStay application initialized');
});
