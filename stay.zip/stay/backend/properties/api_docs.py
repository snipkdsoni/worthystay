from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import status

# Common parameter definitions
property_id_param = openapi.Parameter(
    'id', 
    openapi.IN_PATH, 
    description="ID of the property",
    type=openapi.TYPE_INTEGER
)

property_search_params = [
    openapi.Parameter(
        'q', 
        openapi.IN_QUERY, 
        description="Search query (searches in title, description, city, and address)",
        type=openapi.TYPE_STRING
    ),
    openapi.Parameter(
        'city', 
        openapi.IN_QUERY, 
        description="Filter by city",
        type=openapi.TYPE_STRING
    ),
    openapi.Parameter(
        'type', 
        openapi.IN_QUERY, 
        description="Filter by property type",
        type=openapi.TYPE_STRING
    ),
    openapi.Parameter(
        'maxPrice', 
        openapi.IN_QUERY, 
        description="Maximum price per night",
        type=openapi.TYPE_NUMBER
    ),
    openapi.Parameter(
        'bedrooms', 
        openapi.IN_QUERY, 
        description="Minimum number of bedrooms",
        type=openapi.TYPE_INTEGER
    ),
    openapi.Parameter(
        'amenities', 
        openapi.IN_QUERY, 
        description="Comma-separated list of amenities to filter by",
        type=openapi.TYPE_STRING
    ),
    openapi.Parameter(
        'sort', 
        openapi.IN_QUERY, 
        description="Sort order (prefix with - for descending)",
        type=openapi.TYPE_STRING,
        enum=['price', '-price', 'created_at', '-created_at', 'rating', '-rating']
    ),
    openapi.Parameter(
        'page', 
        openapi.IN_QUERY, 
        description="Page number for pagination",
        type=openapi.TYPE_INTEGER,
        default=1
    ),
]

property_response = {
    status.HTTP_200_OK: openapi.Response(
        description="List of properties",
        schema=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'count': openapi.Schema(type=openapi.TYPE_INTEGER, description='Total number of items'),
                'next': openapi.Schema(type=openapi.TYPE_STRING, format=openapi.FORMAT_URI, description='URL to the next page', nullable=True),
                'previous': openapi.Schema(type=openapi.TYPE_STRING, format=openapi.FORMAT_URI, description='URL to the previous page', nullable=True),
                'results': openapi.Schema(
                    type=openapi.TYPE_ARRAY,
                    items=openapi.Schema(
                        type=openapi.TYPE_OBJECT,
                        properties={
                            'id': openapi.Schema(type=openapi.TYPE_INTEGER, description='Property ID'),
                            'title': openapi.Schema(type=openapi.TYPE_STRING, description='Property title'),
                            'property_type': openapi.Schema(type=openapi.TYPE_STRING, description='Type of property'),
                            'price': openapi.Schema(type=openapi.TYPE_NUMBER, format=openapi.FORMAT_DECIMAL, description='Price per night'),
                            'discount': openapi.Schema(type=openapi.TYPE_INTEGER, description='Discount percentage (0-100)'),
                            'bedrooms': openapi.Schema(type=openapi.TYPE_INTEGER, description='Number of bedrooms'),
                            'bathrooms': openapi.Schema(type=openapi.TYPE_INTEGER, description='Number of bathrooms'),
                            'max_guests': openapi.Schema(type=openapi.TYPE_INTEGER, description='Maximum number of guests'),
                            'city': openapi.Schema(type=openapi.TYPE_STRING, description='City where the property is located'),
                            'country': openapi.Schema(type=openapi.TYPE_STRING, description='Country where the property is located'),
                            'images': openapi.Schema(
                                type=openapi.TYPE_ARRAY,
                                items=openapi.Schema(type=openapi.TYPE_STRING, format=openapi.FORMAT_URI),
                                description='List of image URLs'
                            ),
                            'is_favorite': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='Whether the current user has favorited this property'),
                        }
                    )
                )
            }
        )
    )
}

property_detail_response = {
    status.HTTP_200_OK: openapi.Response(
        description="Property details",
        schema=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'id': openapi.Schema(type=openapi.TYPE_INTEGER, description='Property ID'),
                'title': openapi.Schema(type=openapi.TYPE_STRING, description='Property title'),
                'description': openapi.Schema(type=openapi.TYPE_STRING, description='Detailed description'),
                'property_type': openapi.Schema(type=openapi.TYPE_STRING, description='Type of property'),
                'price': openapi.Schema(type=openapi.TYPE_NUMBER, format=openapi.FORMAT_DECIMAL, description='Price per night'),
                'discount': openapi.Schema(type=openapi.TYPE_INTEGER, description='Discount percentage (0-100)'),
                'bedrooms': openapi.Schema(type=openapi.TYPE_INTEGER, description='Number of bedrooms'),
                'bathrooms': openapi.Schema(type=openapi.TYPE_INTEGER, description='Number of bathrooms'),
                'max_guests': openapi.Schema(type=openapi.TYPE_INTEGER, description='Maximum number of guests'),
                'square_meters': openapi.Schema(type=openapi.TYPE_INTEGER, description='Area in square meters'),
                'address': openapi.Schema(type=openapi.TYPE_STRING, description='Full address'),
                'city': openapi.Schema(type=openapi.TYPE_STRING, description='City'),
                'state': openapi.Schema(type=openapi.TYPE_STRING, description='State/Province'),
                'country': openapi.Schema(type=openapi.TYPE_STRING, description='Country'),
                'postal_code': openapi.Schema(type=openapi.TYPE_STRING, description='Postal code'),
                'latitude': openapi.Schema(type=openapi.TYPE_NUMBER, format=openapi.FORMAT_FLOAT, description='Geographic latitude', nullable=True),
                'longitude': openapi.Schema(type=openapi.TYPE_NUMBER, format=openapi.FORMAT_FLOAT, description='Geographic longitude', nullable=True),
                'amenities': openapi.Schema(
                    type=openapi.TYPE_OBJECT,
                    description='Available amenities',
                    properties={
                        'has_wifi': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='Has WiFi'),
                        'has_kitchen': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='Has kitchen'),
                        'has_air_conditioning': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='Has air conditioning'),
                        'has_heating': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='Has heating'),
                        'has_tv': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='Has TV'),
                        'has_washer': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='Has washer'),
                        'has_dryer': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='Has dryer'),
                        'has_parking': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='Has parking'),
                        'has_pool': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='Has pool'),
                        'has_gym': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='Has gym'),
                    }
                ),
                'minimum_stay': openapi.Schema(type=openapi.TYPE_INTEGER, description='Minimum stay in nights'),
                'maximum_stay': openapi.Schema(type=openapi.TYPE_INTEGER, description='Maximum stay in nights', nullable=True),
                'images': openapi.Schema(
                    type=openapi.TYPE_ARRAY,
                    items=openapi.Schema(
                        type=openapi.TYPE_OBJECT,
                        properties={
                            'id': openapi.Schema(type=openapi.TYPE_INTEGER, description='Image ID'),
                            'url': openapi.Schema(type=openapi.TYPE_STRING, format=openapi.FORMAT_URI, description='Image URL'),
                            'caption': openapi.Schema(type=openapi.TYPE_STRING, description='Image caption', nullable=True),
                            'is_primary': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='Whether this is the primary image')
                        }
                    ),
                    description='List of property images'
                ),
                'host': openapi.Schema(
                    type=openapi.TYPE_OBJECT,
                    properties={
                        'name': openapi.Schema(type=openapi.TYPE_STRING, description='Host name'),
                        'member_since': openapi.Schema(type=openapi.TYPE_STRING, format=openapi.FORMAT_DATE, description='Date when host joined'),
                        'response_rate': openapi.Schema(type=openapi.TYPE_STRING, description='Host response rate'),
                        'response_time': openapi.Schema(type=openapi.TYPE_STRING, description='Host typical response time'),
                        'avatar': openapi.Schema(type=openapi.TYPE_STRING, format=openapi.FORMAT_URI, description='URL to host avatar')
                    },
                    description='Host information'
                ),
                'is_favorite': openapi.Schema(type=openapi.TYPE_BOOLEAN, description='Whether the current user has favorited this property'),
                'created_at': openapi.Schema(type=openapi.TYPE_STRING, format=openapi.FORMAT_DATETIME, description='Creation timestamp'),
                'updated_at': openapi.Schema(type=openapi.TYPE_STRING, format=openapi.FORMAT_DATETIME, description='Last update timestamp')
            }
        )
    ),
    status.HTTP_404_NOT_FOUND: 'Property not found',
    status.HTTP_403_FORBIDDEN: 'Authentication credentials were not provided or are invalid'
}

testimonial_response = {
    status.HTTP_200_OK: openapi.Response(
        description="List of testimonials",
        schema=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'count': openapi.Schema(type=openapi.TYPE_INTEGER, description='Total number of items'),
                'next': openapi.Schema(type=openapi.TYPE_STRING, format=openapi.FORMAT_URI, description='URL to the next page', nullable=True),
                'previous': openapi.Schema(type=openapi.TYPE_STRING, format=openapi.FORMAT_URI, description='URL to the previous page', nullable=True),
                'results': openapi.Schema(
                    type=openapi.TYPE_ARRAY,
                    items=openapi.Schema(
                        type=openapi.TYPE_OBJECT,
                        properties={
                            'id': openapi.Schema(type=openapi.TYPE_INTEGER, description='Testimonial ID'),
                            'name': openapi.Schema(type=openapi.TYPE_STRING, description='Name of the person who gave the testimonial'),
                            'role': openapi.Schema(type=openapi.TYPE_STRING, description='Role or designation of the person', nullable=True),
                            'content': openapi.Schema(type=openapi.TYPE_STRING, description='The testimonial content'),
                            'rating': openapi.Schema(type=openapi.TYPE_INTEGER, description='Rating from 1 to 5'),
                            'image': openapi.Schema(type=openapi.TYPE_STRING, format=openapi.FORMAT_URI, description='URL to profile image', nullable=True),
                            'created_at': openapi.Schema(type=openapi.TYPE_STRING, format=openapi.FORMAT_DATETIME, description='Creation timestamp')
                        }
                    )
                )
            }
        )
    )
}

def property_list_docs():
    """Decorator for property list endpoint documentation"""
    return swagger_auto_schema(
        operation_description="""
        Get a list of properties with optional filtering and search.
        
        ### Search and Filtering
        - Use the `q` parameter to search in title, description, city, and address
        - Filter by city, property type, price range, bedrooms, and amenities
        - Sort results using the `sort` parameter
        
        ### Pagination
        Results are paginated with 12 items per page by default.
        """,
        manual_parameters=property_search_params,
        responses=property_response
    )

def property_detail_docs():
    """Decorator for property detail endpoint documentation"""
    return swagger_auto_schema(
        operation_description="""
        Get detailed information about a specific property.
        
        Includes complete property details, images, and host information.
        """,
        responses=property_detail_response
    )

def property_favorite_docs():
    """Decorator for property favorite toggle endpoint documentation"""
    return swagger_auto_schema(
        operation_description="""
        Toggle favorite status for a property.
        
        Requires authentication. Returns the current favorite status.
        """,
        responses={
            status.HTTP_200_OK: openapi.Response(
                description="Favorite status toggled successfully",
                schema=openapi.Schema(
                    type=openapi.TYPE_OBJECT,
                    properties={
                        'status': openapi.Schema(
                            type=openapi.TYPE_STRING,
                            enum=['added to favorites', 'removed from favorites']
                        )
                    }
                )
            ),
            status.HTTP_401_UNAUTHORIZED: 'Authentication credentials were not provided',
            status.HTTP_404_NOT_FOUND: 'Property not found'
        }
    )

def property_nearby_docs():
    """Decorator for nearby properties endpoint documentation"""
    return swagger_auto_schema(
        operation_description="""
        Find properties near a specific location.
        
        Returns properties within a specified radius (in kilometers) of the given coordinates.
        """,
        manual_parameters=[
            openapi.Parameter(
                'lat', 
                openapi.IN_QUERY, 
                description="Latitude of the center point",
                type=openapi.TYPE_NUMBER,
                required=True
            ),
            openapi.Parameter(
                'lng', 
                openapi.IN_QUERY, 
                description="Longitude of the center point",
                type=openapi.TYPE_NUMBER,
                required=True
            ),
            openapi.Parameter(
                'radius', 
                openapi.IN_QUERY, 
                description="Search radius in kilometers (default: 10)",
                type=openapi.TYPE_NUMBER,
                default=10
            ),
        ],
        responses=property_response
    )
