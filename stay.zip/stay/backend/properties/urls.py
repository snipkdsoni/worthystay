from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views
from .views import PropertyViewSet, TestimonialViewSet, TestMongoDB, MongoDBDataView

# Create a router for ViewSets
router = DefaultRouter()
router.register(r'properties', PropertyViewSet, basename='property')
router.register(r'testimonials', TestimonialViewSet, basename='testimonial')

urlpatterns = [
    # Include the router URLs
    path('', include(router.urls)),
    
    # MongoDB test endpoint
    path('test-mongodb/', TestMongoDB.as_view(), name='test-mongodb'),
    
    # MongoDB data dashboard
    path('mongodb-data/', MongoDBDataView.as_view(), name='mongodb-data'),
    
    # Property likes
    path('properties/<int:property_id>/like/', views.PropertyLikeView.as_view(), name='property-like'),
    path('user/likes/', views.UserLikedPropertiesView.as_view(), name='user-likes'),
    
    # User bookings
    path('user/bookings/', views.UserBookingsView.as_view(), name='user-bookings'),
    
    # Additional custom endpoints can be added here
    path('properties/search/', views.PropertyViewSet.as_view({'get': 'list'}), name='property-search'),
    path('properties/nearby/', views.PropertyViewSet.as_view({'get': 'nearby'}), name='property-nearby'),
    path('properties/<int:pk>/favorite/', views.PropertyViewSet.as_view({
        'post': 'favorite',
        'delete': 'favorite'
    }), name='property-favorite'),
    
    # Admin dashboard
    path('admin/dashboard/', views.admin_dashboard, name='admin-dashboard'),
    path('temp-admin-login/', views.temp_admin_login, name='temp-admin-login'),  # Add this line
]