from django.test import TestCase, RequestFactory
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from rest_framework.test import APITestCase, APIClient
from rest_framework import status
from django.urls import reverse

from .models import Property, PropertyImage, Testimonial
from .serializers import PropertySerializer, PropertyDetailSerializer, TestimonialSerializer

# Get PropertyType from the Property model
PropertyType = Property.PropertyType

User = get_user_model()

class PropertyModelTest(TestCase):
    def setUp(self):
        self.property_data = {
            'title': 'Test Property',
            'description': 'A beautiful test property',
            'property_type': PropertyType.APARTMENT,
            'price': 100.00,
            'bedrooms': 2,
            'bathrooms': 1,
            'max_guests': 4,
            'square_meters': 80,
            'address': '123 Test St',
            'city': 'Test City',
            'state': 'Test State',
            'country': 'Test Country',
            'postal_code': '12345',
            'has_wifi': True,
            'has_kitchen': True,
            'minimum_stay': 2,
        }
        self.property = Property.objects.create(**self.property_data)

    def test_property_creation(self):
        """Test property creation and string representation"""
        self.assertEqual(str(self.property), self.property_data['title'])
        self.assertEqual(self.property.property_type, PropertyType.APARTMENT)
        self.assertEqual(self.property.price, 100.00)
        self.assertTrue(self.property.is_available)

    def test_discount_validation(self):
        """Test discount validation"""
        # Test valid discount
        self.property.discount = 10
        self.property.full_clean()
        
        # Test invalid discount (negative)
        with self.assertRaises(Exception):
            self.property.discount = -5
            self.property.full_clean()
        
        # Test invalid discount (over 100%)
        with self.assertRaises(Exception):
            self.property.discount = 150
            self.property.full_clean()


class PropertyImageViewTest(TestCase):
    def setUp(self):
        self.property = Property.objects.create(
            title='Test Property',
            description='A beautiful test property',
            property_type=PropertyType.APARTMENT,
            price=100.00,
            bedrooms=2,
            bathrooms=1,
            max_guests=4,
            square_meters=80,
            address='123 Test St',
            city='Test City',
            state='Test State',
            country='Test Country',
            postal_code='12345',
            has_wifi=True,
            has_kitchen=True,
            minimum_stay=2,
        )
        
        # Create a test image
        self.test_image = SimpleUploadedFile(
            name='test_image.jpg',
            content=b'fake image content',
            content_type='image/jpeg'
        )
        
        self.image = PropertyImage.objects.create(
            property=self.property,
            image=self.test_image,
            caption='Test Caption',
            is_primary=True
        )
    
    def tearDown(self):
        # Clean up the test image file
        self.image.image.delete()
    
    def test_image_creation(self):
        """Test property image creation and string representation"""
        self.assertEqual(str(self.image), f"Image for {self.property.title}")
        self.assertTrue(self.image.is_primary)
        self.assertEqual(self.image.caption, 'Test Caption')


class PropertyAPITest(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(
            email='test@example.com',
            password='testpass123',
            first_name='Test',
            last_name='User'
        )
        self.client.force_authenticate(user=self.user)
        
        # Create test property
        self.property = Property.objects.create(
            title='Test Property',
            description='A beautiful test property',
            property_type=PropertyType.APARTMENT,
            price=100.00,
            bedrooms=2,
            bathrooms=1,
            max_guests=4,
            square_meters=80,
            address='123 Test St',
            city='Test City',
            state='Test State',
            country='Test Country',
            postal_code='12345',
            has_wifi=True,
            has_kitchen=True,
            minimum_stay=2,
        )

        # Create a test image file in memory
        self.image = SimpleUploadedFile(
            name='test_image.jpg',
            content=b'fake image content',
            content_type='image/jpeg'
        )
        
        # Create test testimonial
        self.testimonial = Testimonial.objects.create(
            name='Test User',
            content='Great property!',
            rating=5,
            property=self.property,
            is_approved=True
        )
    
    def tearDown(self):
        # Clean up test files
        if hasattr(self, 'image') and hasattr(self.image, 'image'):
            self.image.image.delete()
    
    def test_property_list_view(self):
        """Test property list API endpoint"""
        url = reverse('property-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 1)
        self.assertEqual(response.data['results'][0]['title'], self.property.title)
    
    def test_property_detail_view(self):
        """Test property detail API endpoint"""
        url = reverse('property-detail', args=[self.property.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['title'], self.property.title)
        self.assertEqual(len(response.data['images']), 0)
    
    def test_property_search(self):
        """Test property search functionality"""
        url = f"{reverse('property-list')}?q=beautiful&city=Test+City"
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 1)
    
    def test_toggle_favorite_unauthorized(self):
        """Test favorite toggle without authentication"""
        self.client.logout()
        url = reverse('property-favorite', args=[self.property.id])
        response = self.client.post(url)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
    
    def test_toggle_favorite_authorized(self):
        """Test favorite toggle with authentication"""
        url = reverse('property-favorite', args=[self.property.id])
        
        # Add to favorites
        response = self.client.post(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['status'], 'added to favorites')
        self.assertTrue(self.property.favorited_by.filter(id=self.user.id).exists())
        
        # Remove from favorites
        response = self.client.post(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['status'], 'removed from favorites')
        self.assertFalse(self.property.favorited_by.filter(id=self.user.id).exists())


class TestimonialAPITest(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(
            email='test@example.com',
            password='testpass123',
            first_name='Test',
            last_name='User'
        )
        self.client.force_authenticate(user=self.user)
        
        self.property = Property.objects.create(
            title='Test Property',
            description='A beautiful test property',
            property_type=PropertyType.APARTMENT,
            price=100.00,
            bedrooms=2,
            bathrooms=1,
            max_guests=4,
            square_meters=80,
            address='123 Test St',
            city='Test City',
            state='Test State',
            country='Test Country',
            postal_code='12345',
            has_wifi=True,
            has_kitchen=True,
            minimum_stay=2,
        )
        
        # Create approved and unapproved testimonials
        self.approved_testimonial = Testimonial.objects.create(
            name='Approved',
            content='Great!',
            rating=5,
            property=self.property,
            is_approved=True
        )
        self.unapproved_testimonial = Testimonial.objects.create(
            name='Unapproved',
            content='Not bad',
            rating=3,
            property=self.property,
            is_approved=False
        )
        
        self.testimonial_data = {
            'name': 'Test User',
            'content': 'Great experience!',
            'rating': 5,
            'property': self.property.id
        }

    def test_approved_testimonials_only(self):
        """Test that only approved testimonials are returned by default"""
        url = reverse('testimonial-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # Check that only approved testimonials are returned
        self.assertEqual(len(response.data['results']), 1)
        self.assertEqual(response.data['results'][0]['name'], 'Approved')

    def test_create_testimonial(self):
        """Test creating a new testimonial"""
        url = reverse('testimonial-list')
        response = self.client.post(url, self.testimonial_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Testimonial.objects.count(), 3)  # 2 from setUp + 1 new

    def test_rating_validation(self):
        """Test testimonial rating validation"""
        url = reverse('testimonial-list')
        # Test invalid rating (0)
        invalid_data = self.testimonial_data.copy()
        invalid_data['rating'] = 0
        response = self.client.post(url, invalid_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        
        # Test invalid rating (6)
        invalid_data['rating'] = 6
        response = self.client.post(url, invalid_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)