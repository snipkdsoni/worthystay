from django.db import models
from django.utils.translation import gettext_lazy as _
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator, MaxValueValidator
from django.core.exceptions import ValidationError
from django.conf import settings


class Property(models.Model):
    class PropertyType(models.TextChoices):
        APARTMENT = 'apartment', _('Apartment')
        HOUSE = 'house', _('House')
        VILLA = 'villa', _('Villa')
        COTTAGE = 'cottage', _('Cottage')
        CABIN = 'cabin', _('Cabin')
        BED_AND_BREAKFAST = 'bed_and_breakfast', _('Bed and Breakfast')
        OTHER = 'other', _('Other')

    title = models.CharField(_('title'), max_length=200)
    description = models.TextField(_('description'))
    property_type = models.CharField(
        _('property type'),
        max_length=20,
        choices=PropertyType.choices,
        default=PropertyType.APARTMENT
    )
    price = models.DecimalField(_('price per night'), max_digits=10, decimal_places=2)
    discount = models.PositiveIntegerField(
        _('discount percentage'),
        default=0,
        validators=[
            MinValueValidator(0, message=_('Discount cannot be negative')),
            MaxValueValidator(100, message=_('Discount cannot exceed 100%'))
        ],
        help_text=_('Discount percentage (0-100)')
    )
    bedrooms = models.PositiveIntegerField(_('bedrooms'))
    bathrooms = models.PositiveIntegerField(_('bathrooms'))
    max_guests = models.PositiveIntegerField(_('maximum guests'))
    square_meters = models.PositiveIntegerField(_('area in square meters'))
    
    # Location
    address = models.CharField(_('address'), max_length=255)
    city = models.CharField(_('city'), max_length=100)
    state = models.CharField(_('state/province'), max_length=100)
    country = models.CharField(_('country'), max_length=100)
    postal_code = models.CharField(_('postal code'), max_length=20)

    latitude = models.DecimalField(
        _('latitude'),
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True,
        help_text=_('Latitude coordinate')
    )
    
    longitude = models.DecimalField(
        _('longitude'),
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True,
        help_text=_('Longitude coordinate')
    )
    
    # Amenities
    has_wifi = models.BooleanField(_('has WiFi'), default=False)
    has_kitchen = models.BooleanField(_('has kitchen'), default=False)
    has_air_conditioning = models.BooleanField(_('has air conditioning'), default=False)
    has_heating = models.BooleanField(_('has heating'), default=False)
    has_tv = models.BooleanField(_('has TV'), default=False)
    has_washer = models.BooleanField(_('has washer'), default=False)
    has_dryer = models.BooleanField(_('has dryer'), default=False)
    has_parking = models.BooleanField(_('has parking'), default=False)
    has_pool = models.BooleanField(_('has pool'), default=False)
    has_gym = models.BooleanField(_('has gym'), default=False)
    
    # Availability
    is_available = models.BooleanField(_('is available'), default=True)
    minimum_stay = models.PositiveIntegerField(_('minimum stay (nights)'), default=1)
    maximum_stay = models.PositiveIntegerField(_('maximum stay (nights)'), null=True, blank=True)
    
    # Timestamps
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)
    
    # Add many-to-many relationship for users who liked the property
    liked_by = models.ManyToManyField(
        settings.AUTH_USER_MODEL,
        related_name='liked_properties',
        blank=True,
        help_text='Users who have liked this property'
    )
    
    class Meta:
        verbose_name = _('property')
        verbose_name_plural = _('properties')
        ordering = ['-created_at']
    
    def __str__(self):
        return self.title
    
    def save(self, *args, **kwargs):
        # You can add geocoding logic here to set the location based on address
        super().save(*args, **kwargs)


class PropertyImage(models.Model):
    property = models.ForeignKey(Property, related_name='images', on_delete=models.CASCADE)
    image = models.ImageField(_('image'), upload_to='properties/')
    caption = models.CharField(_('caption'), max_length=200, blank=True)
    is_primary = models.BooleanField(_('is primary'), default=False)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    
    class Meta:
        ordering = ['is_primary', 'created_at']
        verbose_name = _('property image')
        verbose_name_plural = _('property images')
    
    def __str__(self):
        return f"Image for {self.property.title}"


class LikedProperty(models.Model):
    """
    Model to track which users have liked which properties
    """
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='property_likes'
    )
    property = models.ForeignKey(
        Property,
        on_delete=models.CASCADE,
        related_name='user_likes'
    )
    liked_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('user', 'property')
        ordering = ['-liked_at']
    
    def __str__(self):
        return f"{self.user.username} liked {self.property.title}"


class Testimonial(models.Model):
    """
    Model to store user testimonials with ratings.
    """
    RATING_CHOICES = [
        (1, '1 Star'),
        (2, '2 Stars'),
        (3, '3 Stars'),
        (4, '4 Stars'),
        (5, '5 Stars'),
    ]
    
    name = models.CharField(_('name'), max_length=100, help_text=_("Name of the person giving the testimonial"))
    role = models.CharField(_('role/designation'), max_length=100, blank=True, 
                           help_text=_("Role or designation of the person (e.g., 'Happy Guest', 'Frequent Traveler')"))
    content = models.TextField(_('testimonial content'), 
                             help_text=_("The testimonial text content"))
    rating = models.PositiveSmallIntegerField(_('rating'), 
                                            choices=RATING_CHOICES,
                                            validators=[
                                                MinValueValidator(1, message=_('Rating cannot be less than 1')),
                                                MaxValueValidator(5, message=_('Rating cannot be more than 5'))
                                            ],
                                            help_text=_('Rating from 1 to 5 stars'))
    image = models.URLField(_('profile image URL'), blank=True, null=True,
                           help_text=_('URL to the profile image of the person'))
    property = models.ForeignKey(Property, on_delete=models.CASCADE, related_name='testimonials',
                               null=True, blank=True, help_text=_('Optional: The property this testimonial is about'))
    is_featured = models.BooleanField(_('featured'), default=False,
                                    help_text=_('Whether this testimonial should be featured on the homepage'))
    is_approved = models.BooleanField(_('approved'), default=False,
                                    help_text=_('Whether this testimonial has been approved for display'))
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)
    
    class Meta:
        verbose_name = _('testimonial')
        verbose_name_plural = _('testimonials')
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['is_approved', 'is_featured', 'rating']),
        ]
    
    def __str__(self):
        return f"{self.name}'s {self.rating}-star review"
    
    def save(self, *args, **kwargs):
        # Ensure rating is within valid range
        if self.rating < 1 or self.rating > 5:
            raise ValidationError(_('Rating must be between 1 and 5'))
        super().save(*args, **kwargs)