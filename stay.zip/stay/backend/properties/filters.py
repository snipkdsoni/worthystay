import django_filters
from django.db.models import Q
from .models import Property

class PropertyFilter(django_filters.FilterSet):
    """
    FilterSet for the Property model with various filtering options.
    """
    min_price = django_filters.NumberFilter(field_name='price', lookup_expr='gte')
    max_price = django_filters.NumberFilter(field_name='price', lookup_expr='lte')
    min_bedrooms = django_filters.NumberFilter(field_name='bedrooms', lookup_expr='gte')
    min_bathrooms = django_filters.NumberFilter(field_name='bathrooms', lookup_expr='gte')
    min_guests = django_filters.NumberFilter(field_name='max_guests', lookup_expr='gte')
    
    # Boolean filters for amenities
    has_wifi = django_filters.BooleanFilter(field_name='has_wifi')
    has_kitchen = django_filters.BooleanFilter(field_name='has_kitchen')
    has_air_conditioning = django_filters.BooleanFilter(field_name='has_air_conditioning')
    has_heating = django_filters.BooleanFilter(field_name='has_heating')
    has_tv = django_filters.BooleanFilter(field_name='has_tv')
    has_washer = django_filters.BooleanFilter(field_name='has_washer')
    has_dryer = django_filters.BooleanFilter(field_name='has_dryer')
    has_parking = django_filters.BooleanFilter(field_name='has_parking')
    has_pool = django_filters.BooleanFilter(field_name='has_pool')
    has_gym = django_filters.BooleanFilter(field_name='has_gym')
    
    # Location filters
    city = django_filters.CharFilter(field_name='city', lookup_expr='iexact')
    country = django_filters.CharFilter(field_name='country', lookup_expr='iexact')
    
    # Property type filter
    property_type = django_filters.ChoiceFilter(
        field_name='property_type',
        choices=Property.PropertyType.choices,
        lookup_expr='iexact'
    )
    
    # Search filter
    search = django_filters.CharFilter(method='filter_search')
    
    class Meta:
        model = Property
        fields = {
            'price': ['lt', 'gt', 'lte', 'gte', 'exact'],
            'bedrooms': ['exact', 'gte', 'lte'],
            'bathrooms': ['exact', 'gte', 'lte'],
            'max_guests': ['exact', 'gte', 'lte'],
            'property_type': ['exact'],
            'is_available': ['exact'],
        }
    
    def filter_search(self, queryset, name, value):
        """
        Custom search filter that searches in multiple fields.
        """
        if not value:
            return queryset
            
        return queryset.filter(
            Q(title__icontains=value) |
            Q(description__icontains=value) |
            Q(address__icontains=value) |
            Q(city__icontains=value) |
            Q(country__icontains=value)
        )
    
    def filter_queryset(self, queryset):
        """
        Override to handle custom filtering logic.
        """
        queryset = super().filter_queryset(queryset)
        
        # Filter by available dates if provided
        check_in = self.data.get('check_in')
        check_out = self.data.get('check_out')
        
        if check_in and check_out:
            # This would require a Booking model to check for availability
            # For now, we'll just return all properties
            pass
            
        return queryset
