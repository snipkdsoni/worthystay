from rest_framework import serializers
from .models import Property, PropertyImage, Testimonial

class PropertyImageSerializer(serializers.ModelSerializer):
    """
    Serializer for property images.
    """
    url = serializers.SerializerMethodField()
    
    class Meta:
        model = PropertyImage
        fields = ['id', 'url', 'caption', 'is_primary']
        read_only_fields = ['id']
    
    def get_url(self, obj):
        """Return full URL for the image."""
        request = self.context.get('request')
        if obj.image and hasattr(obj.image, 'url') and request is not None:
            return request.build_absolute_uri(obj.image.url)
        return None

class PropertySerializer(serializers.ModelSerializer):
    """
    Base serializer for Property model.
    """
    images = serializers.SerializerMethodField()
    is_favorite = serializers.SerializerMethodField()
    
    class Meta:
        model = Property
        fields = [
            'id', 'title', 'property_type', 'price', 'discount', 'bedrooms', 
            'bathrooms', 'max_guests', 'square_meters', 'city', 'country', 
            'address', 'state', 'postal_code', 'latitude', 'longitude',
            'has_wifi', 'has_kitchen', 'has_air_conditioning', 'has_heating',
            'has_tv', 'has_washer', 'has_dryer', 'has_parking', 'has_pool',
            'has_gym', 'is_available', 'minimum_stay', 'maximum_stay',
            'created_at', 'updated_at', 'images', 'is_favorite'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']
    
    def get_images(self, obj):
        """Return list of image URLs for the property."""
        request = self.context.get('request')
        if not request:
            return []
            
        # If property has no images, return a default image
        if not hasattr(obj, 'images') or not obj.images.exists():
            return [
                request.build_absolute_uri('/static/images/default-property.jpg')
            ]
            
        return [
            request.build_absolute_uri(image.image.url) 
            for image in obj.images.all() 
            if hasattr(image, 'image') and hasattr(image.image, 'url')
        ]
    
    def get_is_favorite(self, obj):
        """Check if the current user has favorited this property."""
        request = self.context.get('request')
        if request and hasattr(request, 'user') and request.user.is_authenticated:
            return obj.favorited_by.filter(id=request.user.id).exists()
        return False

class PropertyDetailSerializer(PropertySerializer):
    """
    Detailed serializer for Property including all images and host information.
    """
    image_objects = PropertyImageSerializer(many=True, read_only=True, source='images')
    host = serializers.SerializerMethodField()
    
    class Meta(PropertySerializer.Meta):
        fields = PropertySerializer.Meta.fields + [
            'description', 'has_wifi', 'has_kitchen', 'has_air_conditioning',
            'has_heating', 'has_tv', 'has_washer', 'has_dryer', 'has_parking',
            'has_pool', 'has_gym', 'minimum_stay', 'maximum_stay', 'image_objects', 'host'
        ]
    
    def get_host(self, obj):
        """Return host information."""
        # In a real app, this would come from the property's owner/host
        return {
            'name': 'John Doe',  # Replace with actual host info
            'member_since': '2023-01-01',
            'response_rate': '100%',
            'response_time': 'within an hour',
            'avatar': self.context.get('request').build_absolute_uri('/static/images/default-avatar.jpg') if self.context.get('request') else ''
        }

class PropertyCreateUpdateSerializer(serializers.ModelSerializer):
    """
    Serializer for creating and updating properties.
    """
    images = serializers.ListField(
        child=serializers.URLField(),
        required=False,
        write_only=True,
        help_text="List of image URLs for the property"
    )
    
    class Meta:
        model = Property
        fields = [
            'title', 'description', 'property_type', 'price', 'discount',
            'bedrooms', 'bathrooms', 'max_guests', 'square_meters',
            'address', 'city', 'state', 'country', 'postal_code',
            'latitude', 'longitude', 'amenities', 'is_featured', 'images',
            'has_wifi', 'has_kitchen', 'has_air_conditioning', 'has_heating',
            'has_tv', 'has_washer', 'has_dryer', 'has_parking', 'has_pool',
            'has_gym', 'minimum_stay', 'maximum_stay'
        ]
    
    def create(self, validated_data):
        """Handle property creation with image URLs."""
        image_urls = validated_data.pop('images', [])
        property = Property.objects.create(**validated_data)
        
        # Create PropertyImage instances for each URL
        for index, image_url in enumerate(image_urls):
            PropertyImage.objects.create(
                property=property,
                image=image_url,
                is_primary=(index == 0),  # First image is primary
                caption=f"Property image {index + 1}"
            )
            
        return property
    
    def update(self, instance, validated_data):
        """Handle property update with image URLs."""
        image_urls = validated_data.pop('images', None)
        
        # Update property fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        
        instance.save()
        
        # Update images if provided
        if image_urls is not None:
            # Clear existing images
            instance.images.all().delete()
            
            # Add new images
            for index, image_url in enumerate(image_urls):
                PropertyImage.objects.create(
                    property=instance,
                    image=image_url,
                    is_primary=(index == 0),
                    caption=f"Property image {index + 1}"
                )
        
        return instance

class TestimonialSerializer(serializers.ModelSerializer):
    """
    Serializer for Testimonial model.
    """
    image = serializers.SerializerMethodField()
    
    class Meta:
        model = Testimonial
        fields = ['id', 'name', 'role', 'content', 'rating', 'image', 'created_at']
        read_only_fields = ['id', 'created_at']
    
    def get_image(self, obj):
        """Return a placeholder image URL for the testimonial."""
        request = self.context.get('request')
        if request and hasattr(obj, 'image') and obj.image:
            return request.build_absolute_uri(obj.image.url)
        # Return a default avatar if no image is set
        return request.build_absolute_uri('/static/images/default-avatar.jpg') if request else ''
