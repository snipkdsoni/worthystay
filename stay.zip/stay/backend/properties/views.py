import logging
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse, HttpResponse
from django.db import DatabaseError, IntegrityError
from django.db.models import Q, Count, F, Sum
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, AllowAny
from rest_framework.exceptions import ValidationError, PermissionDenied, NotFound
from rest_framework.views import APIView
from django_filters.rest_framework import DjangoFilterBackend
from .models import Property, Testimonial, PropertyImage, LikedProperty
from .serializers import PropertySerializer, PropertyDetailSerializer, TestimonialSerializer
from .filters import PropertyFilter
from bookings.models import Booking
import math
from bookings.serializers import BookingSerializer

logger = logging.getLogger(__name__)

def handle_view_exception(view_name, exception, request):
    """Helper function to log exceptions and return appropriate responses"""
    logger.error(f"Error in {view_name}: {str(exception)}", exc_info=True, extra={
        'user': request.user.id if hasattr(request, 'user') else None,
        'path': request.path,
        'method': request.method,
        'data': request.POST if request.method == 'POST' else request.GET
    })
    
    if isinstance(exception, (ValidationError, ValueError)):
        return JsonResponse({'error': str(exception)}, status=400)
    elif isinstance(exception, PermissionDenied):
        return JsonResponse({'error': 'Permission denied'}, status=403)
    elif isinstance(exception, (Http404, NotFound)):
        return JsonResponse({'error': 'Not found'}, status=404)
    elif isinstance(exception, (DatabaseError, IntegrityError)):
        return JsonResponse({'error': 'Database error'}, status=500)
    else:
        return JsonResponse({'error': 'An unexpected error occurred'}, status=500)

def home(request):
    """Home page view with featured properties and testimonials"""
    try:
        featured_properties = Property.objects.all()[:6]
        testimonials = Testimonial.objects.all()
        return render(request, 'properties/home.html', {
            'featured_properties': featured_properties,
            'testimonials': testimonials
        })
    except Exception as e:
        return handle_view_exception('home', e, request)

def property_list(request):
    """List properties with filtering and pagination"""
    try:
        properties = Property.objects.all().order_by('-created_at')
        
        # Handle search query
        query = request.GET.get('q')
        if query:
            properties = properties.filter(
                Q(title__icontains=query) |
                Q(description__icontains=query) |
                Q(city__icontains=query) |
                Q(address__icontains=query)
            )
        
        # Handle filters
        try:
            property_type = request.GET.get('type')
            if property_type:
                properties = properties.filter(property_type=property_type)
            
            city = request.GET.get('city')
            if city:
                properties = properties.filter(city=city)
            
            max_price = request.GET.get('maxPrice')
            if max_price:
                properties = properties.filter(price__lte=float(max_price))
            
            bedrooms = request.GET.get('bedrooms')
            if bedrooms:
                properties = properties.filter(bedrooms__gte=int(bedrooms))
            
            amenities = request.GET.get('amenities')
            if amenities:
                amenities_list = amenities.split(',')
                for amenity in amenities_list:
                    properties = properties.filter(amenities__contains=amenity)
            
            sort_by = request.GET.get('sort', '-created_at')
            if sort_by:
                properties = properties.order_by(sort_by)
                
        except (ValueError, TypeError) as e:
            logger.warning(f"Invalid filter parameter: {str(e)}")
            # Continue with unfiltered queryset
        
        # Pagination
        try:
            page = int(request.GET.get('page', 1))
            paginator = Paginator(properties, 12)  # 12 properties per page
            properties = paginator.page(page)
        except (PageNotAnInteger, EmptyPage) as e:
            properties = paginator.page(1)
        except Exception as e:
            logger.error(f"Pagination error: {str(e)}")
            properties = paginator.page(paginator.num_pages)
        
        # For AJAX requests, return only the properties list HTML
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return render(request, 'properties/_property_list.html', {
                'properties': properties,
                'is_ajax': True
            })
        
        return render(request, 'properties/property_list.html', {
            'properties': properties,
            'is_paginated': True,
            'page_obj': properties,
        })
        
    except Exception as e:
        return handle_view_exception('property_list', e, request)

def property_detail(request, pk):
    """Property detail view"""
    try:
        property = get_object_or_404(Property, pk=pk)
        # If using a separate Image model with a ForeignKey to Property
        # images = property.images.all() if hasattr(property, 'images') else []
        # If images are stored as a list in the property model
        images = getattr(property, 'images', [])
        return render(request, 'properties/property_detail.html', {
            'property': property,
            'images': images
        })
    except Exception as e:
        return handle_view_exception('property_detail', e, request)

# AJAX search endpoint
def property_search(request):
    """AJAX search endpoint"""
    try:
        return property_list(request)
    except Exception as e:
        return handle_view_exception('property_search', e, request)

def search_properties(request):
    """Search properties"""
    try:
        query = request.GET.get('q', '')
        city = request.GET.get('city', '')
        property_type = request.GET.get('type', '')
        min_price = request.GET.get('min_price')
        max_price = request.GET.get('max_price')
        
        properties = Property.objects.all()
        
        if city:
            properties = properties.filter(location__icontains=city)
        if property_type:
            properties = properties.filter(type=property_type)
        if min_price:
            properties = properties.filter(price__gte=float(min_price))
        if max_price:
            properties = properties.filter(price__lte=float(max_price))
        
        return render(request, 'properties/_property_list.html', {
            'properties': properties
        })
    except Exception as e:
        return handle_view_exception('search_properties', e, request)

class PropertyViewSet(viewsets.ModelViewSet):
    """
    ViewSet for handling Property CRUD operations and search/filtering
    """
    queryset = Property.objects.all()
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = PropertyFilter
    search_fields = ['title', 'description', 'city', 'country', 'address']
    ordering_fields = ['price', 'created_at', 'rating']
    ordering = ['-created_at']

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return PropertyDetailSerializer
        return PropertySerializer

    def get_permissions(self):
        """
        Instantiates and returns the list of permissions that this view requires.
        """
        if self.action in ['list', 'retrieve', 'search', 'nearby']:
            permission_classes = [AllowAny]
        elif self.action in ['create', 'favorite']:
            permission_classes = [IsAuthenticated]
        else:
            permission_classes = [IsAdminUser]
        return [permission() for permission in permission_classes]

    def get_serializer_context(self):
        """
        Extra context provided to the serializer class.
        """
        return {'request': self.request}

    @action(detail=True, methods=['post'])
    def favorite(self, request, pk=None):
        """
        Toggle favorite status for the current user and property.
        """
        try:
            property = self.get_object()
            user = request.user
            if user in property.favorited_by.all():
                property.favorited_by.remove(user)
                return Response({'status': 'removed from favorites'})
            else:
                property.favorited_by.add(user)
                return Response({'status': 'added to favorites'})
        except Exception as e:
            return handle_view_exception('favorite', e, request)

    @action(detail=False, methods=['get'])
    def nearby(self, request):
        """
        Find properties near a specific location using decimal coordinates.
        Expects 'lat' and 'lng' query parameters.
        """
        try:
            lat = float(request.query_params.get('lat'))
            lng = float(request.query_params.get('lng'))
            radius = float(request.query_params.get('radius', 10))  # Default 10km radius
        except (TypeError, ValueError):
            return Response(
                {'error': 'Invalid or missing lat/lng parameters'},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Simple bounding box filter first (faster than calculating distance for all)
        # 1 degree of latitude is ~111km, 1 degree of longitude is ~111km at equator, less towards poles
        lat_radius = radius / 111.0
        lng_radius = radius / (111.0 * math.cos(math.radians(lat)))
        
        queryset = self.filter_queryset(self.get_queryset())
        
        # Filter properties within the bounding box
        queryset = queryset.filter(
            latitude__isnull=False,
            longitude__isnull=False,
            latitude__range=(lat - lat_radius, lat + lat_radius),
            longitude__range=(lng - lng_radius, lng + lng_radius)
        )
        
        # Calculate distance for each property in the bounding box
        properties_with_distance = []
        for prop in queryset:
            # Haversine formula for distance calculation
            R = 6371  # Earth's radius in km
            dlat = math.radians(prop.latitude - lat)
            dlng = math.radians(prop.longitude - lng)
            a = (math.sin(dlat/2) * math.sin(dlat/2) +
                 math.cos(math.radians(lat)) * math.cos(math.radians(prop.latitude)) *
                 math.sin(dlng/2) * math.sin(dlng/2))
            c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
            distance = R * c
            
            if distance <= radius:
                properties_with_distance.append({
                    'property': prop,
                    'distance_km': round(distance, 2)
                })
        
        # Sort by distance
        properties_with_distance.sort(key=lambda x: x['distance_km'])
        
        # Paginate results
        page = self.paginate_queryset(properties_with_distance)
        if page is not None:
            serializer = PropertySerializer(
                [item['property'] for item in page],
                many=True,
                context={'request': request}
            )
            # Add distance to each property
            for i, item in enumerate(page):
                serializer.data[i]['distance_km'] = item['distance_km']
            return self.get_paginated_response(serializer.data)
        
        serializer = PropertySerializer(
            [item['property'] for item in properties_with_distance],
            many=True,
            context={'request': request}
        )
        # Add distance to each property
        for i, item in enumerate(properties_with_distance):
            serializer.data[i]['distance_km'] = item['distance_km']
        return Response(serializer.data)


class TestimonialViewSet(viewsets.ModelViewSet):
    """
    ViewSet for handling Testimonial CRUD operations
    """
    queryset = Testimonial.objects.all()
    serializer_class = TestimonialSerializer
    permission_classes = [IsAuthenticated, IsAdminUser]
    
    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [AllowAny()]
        return [permission() for permission in self.permission_classes]


from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Property
from .serializers import PropertySerializer

class TestMongoDB(APIView):
    """
    A simple view to display MongoDB data in the browser
    """
    def get(self, request):
        # Get all properties from MongoDB
        properties = Property.objects.all()
        
        # Create a simple HTML response
        html = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>MongoDB Data Viewer</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .property { border: 1px solid #ddd; padding: 15px; margin-bottom: 10px; border-radius: 5px; }
                .property h3 { margin-top: 0; color: #333; }
                .property-details { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px; }
                .property-details div { margin: 5px 0; }
                .success { color: green; font-weight: bold; }
                .danger { color: #d9534f; }
                .info { color: #5bc0de; }
            </style>
        </head>
        <body>
            <h1>MongoDB Data Viewer</h1>
            <p class="success">Successfully connected to MongoDB!</p>
            <p>Total properties in database: <strong>%d</strong></p>
            <div style="margin: 20px 0;">
                <a href="?action=add_test" style="background: #5cb85c; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px;">
                    Add Test Property
                </a>
            </div>
            <div class="properties">
        """ % properties.count()
        
        # Add a test property if requested
        if request.GET.get('action') == 'add_test':
            Property.objects.create(
                title="Test Property " + str(properties.count() + 1),
                description="This is a test property",
                property_type="apartment",
                price=100.00 + (properties.count() * 10),
                bedrooms=2,
                bathrooms=1,
                max_guests=4,
                square_meters=80,
                address=f"{properties.count() + 100} Test St",
                city="Test City",
                state="Test State",
                country="Test Country",
                postal_code="12345"
            )
            # Refresh the page to show the new property
            html += """
                <div class="info" style="padding: 10px; background: #e6f7ff; border-radius: 4px; margin-bottom: 15px;">
                    Test property added! Refreshing...
                </div>
                <script>
                    setTimeout(function() {
                        window.location.href = window.location.pathname;
                    }, 1000);
                </script>
            """
        
        # Add each property to the HTML
        for prop in properties:
            html += f"""
            <div class="property">
                <h3>{prop.title}</h3>
                <div class="property-details">
                    <div><strong>Type:</strong> {prop.property_type}</div>
                    <div><strong>Price:</strong> ${prop.price}/night</div>
                    <div><strong>Bedrooms:</strong> {prop.bedrooms}</div>
                    <div><strong>Bathrooms:</strong> {prop.bathrooms}</div>
                    <div><strong>Max Guests:</strong> {prop.max_guests}</div>
                    <div><strong>Area:</strong> {prop.square_meters} m²</div>
                </div>
                <div style="margin-top: 10px;">
                    <strong>Location:</strong> {prop.address}, {prop.city}, {prop.state}, {prop.country}
                </div>
                <div style="margin-top: 5px; color: #666; font-size: 0.9em;">
                    Added on: {prop.created_at.strftime('%Y-%m-%d %H:%M:%S')}
                </div>
            </div>
            """
        
        # Close HTML tags
        html += """
            </div>
            <div style="margin-top: 20px; color: #666; font-size: 0.9em;">
                <p>This is a simple view showing data from MongoDB. Use the button above to add test properties.</p>
            </div>
        </body>
        </html>
        """
        
        return HttpResponse(html)


class PropertyLikeView(APIView):
    """
    API endpoint to like/unlike a property
    """
    permission_classes = [IsAuthenticated]
    
    def post(self, request, property_id):
        property = get_object_or_404(Property, id=property_id)
        user = request.user
        
        # Check if already liked
        liked = property.liked_by.filter(id=user.id).exists()
        
        if liked:
            # Unlike the property
            property.liked_by.remove(user)
            action = 'unliked'
        else:
            # Like the property
            property.liked_by.add(user)
            action = 'liked'
            
            # Create a LikedProperty record
            LikedProperty.objects.get_or_create(
                user=user,
                property=property
            )
        
        return Response({
            'status': 'success',
            'action': action,
            'likes_count': property.liked_by.count()
        })


class UserLikedPropertiesView(APIView):
    """
    API endpoint to get all properties liked by the current user
    """
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        liked_properties = request.user.liked_properties.all()
        serializer = PropertySerializer(
            liked_properties, 
            many=True,
            context={'request': request}
        )
        return Response(serializer.data)


class UserBookingsView(APIView):
    """
    API endpoint to get all bookings made by the current user
    """
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        from bookings.serializers import BookingSerializer
        
        bookings = request.user.bookings.select_related('property').order_by('-created_at')
        serializer = BookingSerializer(bookings, many=True)
        return Response(serializer.data)


class MongoDBDataView(APIView):
    """
    View to display MongoDB data in a user-friendly dashboard
    """
    def get(self, request):
        # Get all properties with like count and booking info
        properties = Property.objects.annotate(
            likes_count=Count('liked_by'),
            bookings_count=Count('bookings')
        )
        
        # Get recent likes
        recent_likes = LikedProperty.objects.select_related('user', 'property') \
                                           .order_by('-liked_at')[:10]
        
        # Get recent bookings
        recent_bookings = Booking.objects.select_related('user', 'property') \
                                       .order_by('-created_at')[:10]
        
        # Prepare context data
        context = {
            'properties_count': properties.count(),
            'total_likes': sum(p.likes_count for p in properties),
            'total_bookings': sum(p.bookings_count for p in properties),
            'recent_likes': [
                {
                    'user': like.user.username,
                    'property': like.property.title,
                    'location': f"{like.property.city}, {like.property.country}",
                    'liked_at': like.liked_at.strftime('%Y-%m-%d %H:%M:%S')
                }
                for like in recent_likes
            ],
            'recent_bookings': [
                {
                    'user': booking.user.username,
                    'property': booking.property.title,
                    'check_in': booking.check_in.strftime('%Y-%m-%d'),
                    'check_out': booking.check_out.strftime('%Y-%m-%d'),
                    'guests': booking.guests,
                    'total_price': str(booking.total_price),
                    'status': booking.status,
                    'booked_at': booking.created_at.strftime('%Y-%m-%d %H:%M:%S')
                }
                for booking in recent_bookings
            ]
        }
        
        # Return JSON for API requests
        if request.accepted_renderer.format == 'json':
            return Response(context)
            
        # Render HTML template for browser requests
        return render(request, 'mongodb_dashboard.html', context)


from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import Property

@login_required
def admin_dashboard(request):
    """
    Simple admin view to show ONLY liked and booked properties in MongoDB format
    """
    # Get liked properties (just IDs and titles)
    liked_properties = list(
        Property.objects
        .filter(liked_by=request.user)
        .values('id', 'title', 'city', 'country')
    )
    
    # Get booked properties (just IDs and titles with booking dates)
    booked_properties = []
    for prop in Property.objects.filter(bookings__user=request.user).distinct():
        bookings = prop.bookings.filter(user=request.user).values('check_in', 'check_out', 'status')
        booked_properties.append({
            'id': prop.id,
            'title': prop.title,
            'city': prop.city,
            'country': prop.country,
            'bookings': list(bookings)
        })
    
    data = {
        'liked_properties': liked_properties,
        'booked_properties': booked_properties
    }
    
    return JsonResponse(data, json_dumps_params={'indent': 2})

from django.contrib.auth import authenticate, login

def temp_admin_login(request):
    """
    Temporary view to log in as admin for testing
    """
    from django.contrib.auth.models import User
    
    # Create admin user if it doesn't exist
    if not User.objects.filter(username='admin').exists():
        User.objects.create_superuser('admin', 'admin@example.com', 'admin123')
    
    # Authenticate and login
    user = authenticate(username='admin', password='admin123')
    if user is not None:
        login(request, user)
        return HttpResponse('Successfully logged in as admin. <a href="/admin/">Go to admin</a> or <a href="/">Go to home</a>')
    return HttpResponse('Login failed')