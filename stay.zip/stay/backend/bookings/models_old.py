from django.db import models
from django.utils.translation import gettext_lazy as _
from django.conf import settings
from properties.models import Property


class BookingStatus(models.TextChoices):
    PENDING = 'pending', _('Pending')
    CONFIRMED = 'confirmed', _('Confirmed')
    CANCELLED = 'cancelled', _('Cancelled')
    COMPLETED = 'completed', _('Completed')


class Booking(models.Model):
    """
    Model to store property booking information
    """
    property = models.ForeignKey(
        Property,
        on_delete=models.CASCADE,
        related_name='bookings',
        verbose_name=_('property')
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='bookings',
        verbose_name=_('user')
    )
    status = models.CharField(
        _('status'),
        max_length=20,
        choices=BookingStatus.choices,
        default=BookingStatus.PENDING
    )
    check_in = models.DateField(_('check-in date'))
    check_out = models.DateField(_('check-out date'))
    guests = models.PositiveIntegerField(_('number of guests'))
    total_price = models.DecimalField(
        _('total price'),
        max_digits=10,
        decimal_places=2
    )
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)
    special_requests = models.TextField(_('special requests'), blank=True)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = _('booking')
        verbose_name_plural = _('bookings')
    
    def __str__(self):
        return f"Booking #{self.id} - {self.property.title} by {self.user.email}"
    
    def save(self, *args, **kwargs):
        # Calculate total price if not set
        if not self.total_price and self.check_in and self.check_out and self.property:
            nights = (self.check_out - self.check_in).days
            self.total_price = self.property.price_per_night * nights
        super().save(*args, **kwargs)
    
    @property
    def calculate_nights(self):
        """Calculate and return the number of nights for the booking"""
        if self.check_in and self.check_out:
            return (self.check_out - self.check_in).days
        return 0
