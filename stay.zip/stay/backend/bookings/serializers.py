from rest_framework import serializers
from django.utils import timezone
from .models import Booking, BookingStatus
from properties.serializers import PropertySerializer as PropertyListSerializer
from users.serializers import UserSerializer


class BookingSerializer(serializers.ModelSerializer):
    """
    Serializer for the Booking model
    """
    property = PropertyListSerializer(read_only=True)
    user = UserSerializer(read_only=True)
    status_display = serializers.CharField(
        source='get_status_display', 
        read_only=True
    )
    can_cancel = serializers.SerializerMethodField()
    
    class Meta:
        model = Booking
        fields = [
            'id', 'property', 'user', 'status', 'status_display',
            'check_in', 'check_out', 'guests', 'total_price',
            'created_at', 'special_requests', 'can_cancel'
        ]
        read_only_fields = [
            'id', 'property', 'user', 'status', 'status_display',
            'created_at', 'updated_at', 'total_price', 'can_cancel'
        ]
    
    def get_can_cancel(self, obj):
        """Check if the booking can be cancelled"""
        return obj.status in [BookingStatus.PENDING, BookingStatus.CONFIRMED]


class CreateBookingSerializer(serializers.ModelSerializer):
    """
    Serializer for creating a new booking
    """
    class Meta:
        model = Booking
        fields = [
            'property', 'check_in', 'check_out', 'guests',
            'special_requests'
        ]
    
    def validate(self, data):
        """
        Validate the booking data
        """
        # Check if check_out is after check_in
        if data['check_out'] <= data['check_in']:
            raise serializers.ValidationError({
                'check_out': 'Check-out date must be after check-in date.'
            })
        
        # Check if dates are in the future
        today = timezone.now().date()
        if data['check_in'] < today:
            raise serializers.ValidationError({
                'check_in': 'Check-in date cannot be in the past.'
            })
        
        # Check property availability
        property = data['property']
        overlapping_bookings = property.bookings.filter(
            check_out__gt=data['check_in'],
            check_in__lt=data['check_out'],
            status__in=[BookingStatus.PENDING, BookingStatus.CONFIRMED]
        ).exists()
        
        if overlapping_bookings:
            raise serializers.ValidationError({
                'non_field_errors': ['The property is not available for the selected dates.']
            })
        
        # Check guest count
        if data['guests'] > property.max_guests:
            raise serializers.ValidationError({
                'guests': f'Maximum {property.max_guests} guests allowed for this property.'
            })
        
        return data
    
    def create(self, validated_data):
        """
        Create and return a new booking instance
        """
        request = self.context.get('request')
        property = validated_data['property']
        
        # Calculate total price
        nights = (validated_data['check_out'] - validated_data['check_in']).days
        total_price = property.price * nights
        
        # Create booking
        booking = Booking.objects.create(
            user=request.user,
            property=property,
            total_price=total_price,
            **validated_data
        )
        
        return booking


class UpdateBookingStatusSerializer(serializers.ModelSerializer):
    """
    Serializer for updating booking status (used by hosts/admins)
    """
    class Meta:
        model = Booking
        fields = ['status']
    
    def validate_status(self, value):
        """
        Validate status transitions
        """
        valid_transitions = {
            BookingStatus.PENDING: [BookingStatus.CONFIRMED, BookingStatus.CANCELLED],
            BookingStatus.CONFIRMED: [BookingStatus.CANCELLED, BookingStatus.COMPLETED],
            BookingStatus.CANCELLED: [],
            BookingStatus.COMPLETED: []
        }
        
        current_status = self.instance.status
        if value not in valid_transitions.get(current_status, []):
            raise serializers.ValidationError(
                f'Cannot change status from {current_status} to {value}'
            )
        
        return value
