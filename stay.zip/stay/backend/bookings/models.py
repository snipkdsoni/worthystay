﻿from django.db import models
from django.conf import settings
from properties.models import Property
from django.utils import timezone

class BookingStatus(models.TextChoices):
    PENDING = 'pending', 'Pending'
    CONFIRMED = 'confirmed', 'Confirmed'
    CANCELLED = 'cancelled', 'Cancelled'
    COMPLETED = 'completed', 'Completed'
    REJECTED = 'rejected', 'Rejected'

class Booking(models.Model):
    property = models.ForeignKey(Property, on_delete=models.CASCADE, related_name='bookings')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='bookings')
    status = models.CharField(
        max_length=20, 
        choices=BookingStatus.choices, 
        default=BookingStatus.PENDING
    )
    check_in = models.DateField()
    check_out = models.DateField()
    guests = models.PositiveIntegerField()
    total_price = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    special_requests = models.TextField(blank=True)
    cancellation_reason = models.TextField(blank=True, null=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status']),
            models.Index(fields=['check_in', 'check_out']),
            models.Index(fields=['user']),
        ]

    def __str__(self):
        return f"Booking #{self.id} - {self.property.title} - {self.status}"

    def get_nights(self):
        if self.check_in and self.check_out:
            return (self.check_out - self.check_in).days
        return 0
        
    def is_upcoming(self):
        return self.check_in > timezone.now().date() and self.status == BookingStatus.CONFIRMED
        
    def is_active(self):
        today = timezone.now().date()
        return self.check_in <= today <= self.check_out and self.status == BookingStatus.CONFIRMED
        
    def cancel(self, reason=None, save=True):
        self.status = BookingStatus.CANCELLED
        if reason:
            self.cancellation_reason = reason
        if save:
            self.save()

    def confirm(self, save=True):
        self.status = BookingStatus.CONFIRMED
        if save:
            self.save()

    def complete(self, save=True):
        self.status = BookingStatus.COMPLETED
        if save:
            self.save()
