from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

# Create a router for ViewSets
router = DefaultRouter()
router.register(r'bookings', views.BookingViewSet, basename='booking')

app_name = 'bookings'

urlpatterns = [
    # Include the router URLs
    path('', include(router.urls)),
    
    # Additional custom endpoints can be added here
    path('properties/<int:property_id>/check-availability/', 
         views.check_property_availability, 
         name='check-availability'),
]
