from django.shortcuts import render
from rest_framework import viewsets, status, mixins, permissions
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.shortcuts import get_object_or_404
from django.utils import timezone

from .models import Booking, BookingStatus
from .serializers import (
    BookingSerializer,
    CreateBookingSerializer,
    UpdateBookingStatusSerializer
)
from properties.models import Property


class BookingViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.DestroyModelMixin,
    viewsets.GenericViewSet
):
    """
    ViewSet for handling booking operations
    """
    permission_classes = []  # No authentication required
    
    def get_queryset(self):
        """
        Return bookings for the current user, or all bookings for admin users
        """
        return Booking.objects.all().select_related('property', 'user')
    
    def get_serializer_class(self):
        """
        Return appropriate serializer class based on action
        """
        if self.action == 'create':
            return CreateBookingSerializer
        elif self.action == 'update_status':
            return UpdateBookingStatusSerializer
        return BookingSerializer
    
    def get_permissions(self):
        """
        Set permissions based on action
        """
        if self.action in ['update_status', 'destroy']:
            self.permission_classes = [IsAdminUser]
        return []  # No authentication required
    
    def create(self, request, *args, **kwargs):
        """
        Create a new booking
        """
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        booking = serializer.save()
        
        # Get the full booking details with related data
        booking_serializer = BookingSerializer(
            booking,
            context={'request': request}
        )
        
        return Response(
            booking_serializer.data,
            status=status.HTTP_201_CREATED
        )
    
    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        """
        Cancel a booking (user-initiated cancellation)
        """
        booking = self.get_object()
        
        # Only allow cancellation of pending or confirmed bookings
        if booking.status not in [BookingStatus.PENDING, BookingStatus.CONFIRMED]:
            return Response(
                {'detail': 'This booking cannot be cancelled.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Only the booking owner can cancel
        if booking.user != request.user and not request.user.is_staff:
            return Response(
                {'detail': 'You do not have permission to cancel this booking.'},
                status=status.HTTP_403_FORBIDDEN
            )
        
        booking.status = BookingStatus.CANCELLED
        booking.save()
        
        return Response(
            {'status': 'Booking cancelled successfully'},
            status=status.HTTP_200_OK
        )
    
    @action(detail=True, methods=['post'])
    def update_status(self, request, pk=None):
        """
        Update booking status (admin only)
        """
        booking = self.get_object()
        serializer = self.get_serializer(booking, data=request.data)
        serializer.is_valid(raise_exception=True)
        
        # Save the updated status
        booking = serializer.save()
        
        return Response(
            {'status': f'Booking status updated to {booking.get_status_display()}'},
            status=status.HTTP_200_OK
        )
    
    @action(detail=False, methods=['get'])
    def upcoming(self, request):
        """
        Get upcoming bookings (check-in date is in the future)
        """
        queryset = self.get_queryset().filter(
            check_in__gte=timezone.now().date(),
            status__in=[BookingStatus.PENDING, BookingStatus.CONFIRMED]
        ).order_by('check_in')
        
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def past(self, request):
        """
        Get past bookings (check-out date is in the past)
        """
        queryset = self.get_queryset().filter(
            check_out__lt=timezone.now().date()
        ).order_by('-check_out')
        
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def check_property_availability(request, property_id):
    """
    Check if a property is available for the given dates
    """
    property = get_object_or_404(Property, id=property_id)
    
    # Get query parameters
    check_in = request.query_params.get('check_in')
    check_out = request.query_params.get('check_out')
    
    # Validate dates
    if not (check_in and check_out):
        return Response(
            {'error': 'Both check_in and check_out parameters are required'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        check_in_date = timezone.datetime.strptime(check_in, '%Y-%m-%d').date()
        check_out_date = timezone.datetime.strptime(check_out, '%Y-%m-%d').date()
    except ValueError:
        return Response(
            {'error': 'Invalid date format. Use YYYY-MM-DD'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    # Check if check_out is after check_in
    if check_out_date <= check_in_date:
        return Response(
            {'error': 'Check-out date must be after check-in date'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    # Check if dates are in the future
    today = timezone.now().date()
    if check_in_date < today:
        return Response(
            {'error': 'Check-in date cannot be in the past'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    # Check for overlapping bookings
    is_available = not Booking.objects.filter(
        property=property,
        check_out__gt=check_in_date,
        check_in__lt=check_out_date,
        status__in=[BookingStatus.PENDING, BookingStatus.CONFIRMED]
    ).exists()
    
    # Calculate total price if available
    total_price = None
    if is_available:
        nights = (check_out_date - check_in_date).days
        total_price = property.price * nights
    
    return Response({
        'is_available': is_available,
        'property_id': property.id,
        'property_title': property.title,
        'check_in': check_in_date,
        'check_out': check_out_date,
        'total_nights': property.calculate_nights(check_in_date, check_out_date) if is_available else 0,
        'price': property.price,
        'total_price': total_price,
        'max_guests': property.max_guests,
        'currency': 'USD'  # You can make this dynamic based on your requirements
    })
