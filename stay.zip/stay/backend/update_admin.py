# update_admin.py
from pymongo import MongoClient
from bson.objectid import ObjectId

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['worthystay']
collection = db['users_customuser']

# Find and update the admin user
result = collection.update_one(
    {'email': 'admin@example.com'},
    {
        '$set': {
            'is_superuser': True,
            'is_staff': True,
            'is_active': True
        }
    }
)

if result.modified_count > 0:
    print("Admin user updated successfully!")
    print("Email: admin@example.com")
    print("Password: admin123")
else:
    print("Failed to update admin user. The user may not exist.")