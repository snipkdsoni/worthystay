# create_new_admin.py
import os
import django
from bson.objectid import ObjectId
import datetime

# Set up Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from pymongo import MongoClient
from django.contrib.auth.hashers import make_password

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['worthystay']
collection = db['users_customuser']

# New admin user data
new_admin = {
    'email': 'newadmin@example.com',
    'password': make_password('admin123'),
    'first_name': 'New',
    'last_name': 'Admin',
    'is_staff': True,
    'is_superuser': True,
    'is_active': True,
    'date_joined': datetime.datetime.utcnow()
}

# Insert the new admin user
result = collection.insert_one(new_admin)

if result.inserted_id:
    print("New admin user created successfully!")
    print("Email: newadmin@example.com")
    print("Password: admin123")
    print("You can now log in at http://127.0.0.1:8000/admin/")
else:
    print("Failed to create new admin user.")