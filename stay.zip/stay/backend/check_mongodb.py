from pymongo import MongoClient

try:
    # Try to connect to the MongoDB server
    client = MongoClient('localhost', 27017)
    
    # The ismaster command is cheap and does not require authentication
    client.admin.command('ismaster')
    print("Successfully connected to MongoDB!")
    
    # List all database names
    print("Available databases:", client.list_database_names())
    
except Exception as e:
    print("Error connecting to MongoDB:", str(e))
finally:
    client.close()