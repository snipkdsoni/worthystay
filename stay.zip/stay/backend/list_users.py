# list_users.py
from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['worthystay']
collection = db['users_customuser']

# List all users
print("Users in the database:")
for user in collection.find():
    print("\nUser document:")
    for key, value in user.items():
        print(f"{key}: {value}")