from pymongo import MongoClient

client = MongoClient('mongodb://localhost:27017/')
db = client['worthystay']

collection_name = 'bookings_booking'
if collection_name in db.list_collection_names():
    db.drop_collection(collection_name)
    print(f"Collection '{collection_name}' dropped successfully.")
else:
    print(f"Collection '{collection_name}' does not exist.")

client.close()
