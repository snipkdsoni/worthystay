from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
from properties.views import admin_dashboard  # Import the admin_dashboard view

schema_view = get_schema_view(
    openapi.Info(
        title="WorthyStay API",
        default_version='v1',
        description="API for WorthyStay vacation rental platform",
        terms_of_service="https://www.worthystay.com/terms/",
        contact=openapi.Contact(email="contact@worthystay.com"),
        license=openapi.License(name="BSD License"),
    ),
    public=True,
    permission_classes=(permissions.AllowAny,),
)

urlpatterns = [
    # Admin
    path('admin/', admin_dashboard, name='admin-dashboard'),  # Simple admin dashboard
    path('admin/dashboard/', admin.site.urls),  # Admin dashboard
    
    # API Documentation
    path('api/docs/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    path('api/redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
    
    # API Endpoints
    path('api/properties/', include('properties.urls')),
    path('api/bookings/', include('bookings.urls')),
]

# Conditionally include frontend URLs only if the app exists
if settings.DEBUG:
    try:
        import frontend.urls
        urlpatterns += [path('', include('frontend.urls'))]
    except ImportError:
        pass

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)