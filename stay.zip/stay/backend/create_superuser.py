# worthystay/create_superuser.py
import os
import sys
import django

# Set up Django environment
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from django.contrib.auth import get_user_model

# Get the custom user model
User = get_user_model()

# Create superuser
email = input("Enter admin email: ")
password = input("Enter admin password: ")

User.objects.create_superuser(
    email=email,
    password=password,
    first_name="Admin",
    last_name="User"
)

print("\nSuperuser created successfully!")
print(f"Email: {email}")