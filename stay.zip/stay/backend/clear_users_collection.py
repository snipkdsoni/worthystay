from pymongo import MongoClient

client = MongoClient('mongodb://localhost:27017/')
db = client['worthystay']
collection = db['users_customuser']

result = collection.delete_many({})
print(f"Deleted {result.deleted_count} documents from users_customuser collection.")

client.close()
