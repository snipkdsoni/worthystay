# reset_users.py
import os
import django
from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['worthystay']

# Drop the users collection
db['users_customuser'].drop()
print("Dropped users_customuser collection")

# Set up Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from django.contrib.auth import get_user_model
User = get_user_model()

try:
    # First create a regular user
    user = User.objects.create_user(
        email='admin@example.com',
        password='admin123',
        first_name='Admin',
        last_name='User'
    )
    
    # Then update the flags
    user.is_staff = True
    user.is_superuser = True
    user.is_active = True
    
    # Save without any update_fields to ensure all fields are saved
    user.save(update_fields=['is_staff', 'is_superuser', 'is_active', 'password'])
    
    print("\nAdmin user created successfully!")
    print("Email: admin@example.com")
    print("Password: admin123")
    
except Exception as e:
    print(f"\nError creating admin user: {e}")
    print("\nPlease run these commands manually:")
    print("1. python manage.py makemigrations")
    print("2. python manage.py migrate")
    print("3. python manage.py createsuperuser")