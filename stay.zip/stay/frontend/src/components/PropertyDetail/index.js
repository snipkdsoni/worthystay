import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  FaBed, FaBath, FaRulerCombined, FaHeart, FaMapMarkerAlt, 
  FaStar, FaRegStar, FaArrowLeft, FaWifi, FaParking, FaSwimmingPool,
  FaTv, FaSnowflake, FaDumbbell, FaWheelchair, FaDog, FaCalendarAlt
} from 'react-icons/fa';
import { MdOutlineBalcony, MdOutlineElevator, MdOutlineLocalLaundryService } from 'react-icons/md';
import { BiArea } from 'react-icons/bi';
import { IoMdPricetag } from 'react-icons/io';

const PropertyDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isFavorite, setIsFavorite] = useState(false);
  const [showAllAmenities, setShowAllAmenities] = useState(false);
  const [showContactForm, setShowContactForm] = useState(false);
  
  // Mock property data - replace with API call
  const property = {
    id: id,
    title: 'Luxury 2BHK Apartment in HSR Layout',
    type: 'apartment',
    price: 35000,
    rating: 4.5,
    reviewCount: 128,
    bedrooms: 2,
    bathrooms: 2,
    area: 1200,
    location: 'HSR Layout, Bangalore',
    description: 'Beautiful 2BHK apartment with modern amenities in prime location.',
    images: [
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80',
      'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80',
    ],
    amenities: [
      { icon: <FaWifi />, name: 'WiFi' },
      { icon: <FaParking />, name: 'Parking' },
      { icon: <FaSwimmingPool />, name: 'Pool' },
      { icon: <FaTv />, name: 'TV' },
      { icon: <FaSnowflake />, name: 'AC' },
      { icon: <MdOutlineBalcony />, name: 'Balcony' },
      { icon: <MdOutlineElevator />, name: 'Lift' },
      { icon: <FaDumbbell />, name: 'Gym' },
    ],
    address: '123, 5th Main Road, Sector 6, HSR Layout, Bangalore - 560102',
    rules: [
      'No smoking inside',
      'No parties/events',
      'Check-in after 2:00 PM',
      'Check-out before 11:00 AM'
    ]
  };

  const nextImage = () => {
    setCurrentImageIndex(prev => (prev + 1) % property.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex(prev => (prev - 1 + property.images.length) % property.images.length);
  };

  const renderRating = (rating) => {
    return Array(5).fill(0).map((_, i) => (
      i < Math.floor(rating) ? 
      <FaStar key={i} className="star filled" /> : 
      <FaRegStar key={i} className="star" />
    ));
  };

  return (
    <div className="property-detail-page">
      <div className="container">
        <button className="back-button" onClick={() => navigate(-1)}>
          <FaArrowLeft /> Back to Properties
        </button>
        
        <div className="property-header">
          <h1>{property.title}</h1>
          <div className="property-location">
            <FaMapMarkerAlt /> {property.location}
          </div>
          <div className="property-rating">
            {renderRating(property.rating)}
            <span>({property.reviewCount} reviews)</span>
          </div>
        </div>

        <div className="property-gallery">
          <div className="main-image">
            <img src={property.images[currentImageIndex]} alt={property.title} />
            <button className="nav-arrow left-arrow" onClick={prevImage}>&#10094;</button>
            <button className="nav-arrow right-arrow" onClick={nextImage}>&#10095;</button>
            <button 
              className={`favorite-button ${isFavorite ? 'favorited' : ''}`}
              onClick={() => setIsFavorite(!isFavorite)}
            >
              <FaHeart />
            </button>
          </div>
        </div>

        <div className="property-content">
          <div className="property-main">
            <div className="property-highlights">
              <div className="highlight">
                <FaBed />
                <span>{property.bedrooms} Beds</span>
              </div>
              <div className="highlight">
                <FaBath />
                <span>{property.bathrooms} Baths</span>
              </div>
              <div className="highlight">
                <BiArea />
                <span>{property.area} sq.ft</span>
              </div>
              <div className="highlight price">
                <IoMdPricetag />
                <span>₹{property.price.toLocaleString()}/month</span>
              </div>
            </div>

            <div className="property-section">
              <h2>About this property</h2>
              <p>{property.description}</p>
            </div>

            <div className="property-section">
              <h2>Amenities</h2>
              <div className="amenities-grid">
                {property.amenities.map((amenity, i) => (
                  <div key={i} className="amenity-item">
                    <span className="amenity-icon">{amenity.icon}</span>
                    <span>{amenity.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="property-sidebar">
            <div className="booking-card">
              <div className="price">₹{property.price.toLocaleString()}<span>/month</span></div>
              <button 
                className="btn btn-primary"
                onClick={() => setShowContactForm(!showContactForm)}
              >
                {showContactForm ? 'Hide Contact Form' : 'Contact Owner'}
              </button>
              
              {showContactForm && (
                <form className="contact-form">
                  <input type="text" placeholder="Your Name" required />
                  <input type="email" placeholder="Your Email" required />
                  <input type="tel" placeholder="Phone Number" required />
                  <textarea placeholder="Your Message"></textarea>
                  <button type="submit" className="btn btn-primary">Send Message</button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyDetail;
