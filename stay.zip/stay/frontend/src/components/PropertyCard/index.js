import React, { useState } from 'react';
import { FaHeart, FaMapMarkerAlt, FaStar } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import './PropertyCard.css';

const PropertyCard = ({ property }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isFavorite, setIsFavorite] = useState(false);
  const navigate = useNavigate();

  const handlePrevImage = (e) => {
    e.stopPropagation();
    setCurrentImageIndex(prev => 
      prev === 0 ? property.images.length - 1 : prev - 1
    );
  };

  const handleNextImage = (e) => {
    e.stopPropagation();
    setCurrentImageIndex(prev => 
      prev === property.images.length - 1 ? 0 : prev + 1
    );
  };

  const toggleFavorite = (e) => {
    e.stopPropagation();
    setIsFavorite(!isFavorite);
  };

  const handleCardClick = () => {
    navigate(`/properties/${property.id}`);
  };

  return (
    <div className="property-card" onClick={handleCardClick}>
      <div className="property-image-container">
        <img 
          src={property.images[currentImageIndex]} 
          alt={property.title} 
          className="property-image"
        />
        
        {property.images.length > 1 && (
          <>
            <button 
              className="nav-arrow left-arrow"
              onClick={handlePrevImage}
              aria-label="Previous image"
            >
              &lt;
            </button>
            <button 
              className="nav-arrow right-arrow"
              onClick={handleNextImage}
              aria-label="Next image"
            >
              &gt;
            </button>
          </>
        )}
        
        <div className="property-badges">
          {property.isVerified && (
            <span className="badge verified">Verified</span>
          )}
          {property.discount && (
            <span className="badge discount">{property.discount}% OFF</span>
          )}
        </div>
        
        <button 
          className={`favorite-button ${isFavorite ? 'favorited' : ''}`}
          onClick={toggleFavorite}
          aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
        >
          <FaHeart />
        </button>
      </div>
      
      <div className="property-details">
        <div className="property-header">
          <h3 className="property-title">{property.title}</h3>
          <div className="property-location">
            <FaMapMarkerAlt className="location-icon" />
            <span>{property.location}</span>
          </div>
        </div>
        
        <div className="property-footer">
          <div className="property-price">
            <span className="price">₹{property.price.toLocaleString()}</span>
            <span className="period">/month</span>
          </div>
          
          <div className="property-rating">
            <FaStar className="star-icon" />
            <span>{property.rating}</span>
            <span className="review-count">({property.reviewCount})</span>
          </div>
        </div>
        
        <div className="property-actions">
          <button 
            className="btn btn-outline"
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/properties/${property.id}`);
            }}
          >
            View Details
          </button>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;
