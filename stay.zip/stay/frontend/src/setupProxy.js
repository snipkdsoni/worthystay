const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  app.use(
    '/api', // Only proxy requests that start with /api
    createProxyMiddleware({
      target: 'http://localhost:8000',
      changeOrigin: true,
      // Don't forward static assets
      pathRewrite: {
        '^/api': '', // Remove /api prefix when forwarding to backend
      },
      // Don't log proxy errors for static files
      logLevel: process.env.NODE_ENV === 'development' ? 'debug' : 'silent',
    })
  );
};
