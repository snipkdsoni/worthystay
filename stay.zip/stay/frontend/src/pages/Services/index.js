import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FaSearch, FaHome, FaShieldAlt, FaCalendarAlt, FaPhoneAlt, FaMapMarkedAlt } from 'react-icons/fa';
import { MdOutlineSupportAgent, MdOutlinePayments } from 'react-icons/md';
import { BsHouseCheck } from 'react-icons/bs';
import './Services.css';

const Services = () => {
  const navigate = useNavigate();

  const handleBrowseProperties = () => {
    navigate('/properties');
  };

  const handleContactSupport = () => {
    // You can also navigate to a dedicated contact page if you have one
    // navigate('/contact');
    
    // For now, let's scroll to the contact section if it exists on the home page
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    } else {
      // If no contact section is found, navigate to home page which should have it
      navigate('/');
      // Small delay to ensure the page has loaded before scrolling
      setTimeout(() => {
        document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  };

  const services = [
    {
      icon: <FaSearch className="service-icon" />,
      title: 'Smart Search',
      description: 'Find your perfect stay with our advanced search filters and personalized recommendations.'
    },
    {
      icon: <FaHome className="service-icon" />,
      title: 'Verified Listings',
      description: 'Every property is personally verified to ensure quality and accuracy of listings.'
    },
    {
      icon: <FaShieldAlt className="service-icon" />,
      title: 'Secure Booking',
      description: 'Your safety is our priority with secure payment processing and data protection.'
    },
    {
      icon: <FaCalendarAlt className="service-icon" />,
      title: 'Flexible Stays',
      description: 'From short getaways to long-term rentals, we offer flexible booking options.'
    },
    {
      icon: <MdOutlineSupportAgent className="service-icon" />,
      title: '24/7 Support',
      description: 'Our dedicated support team is available around the clock to assist you.'
    },
    {
      icon: <BsHouseCheck className="service-icon" />,
      title: 'Property Management',
      description: 'Comprehensive tools and support for property owners to manage their listings.'
    },
    {
      icon: <FaMapMarkedAlt className="service-icon" />,
      title: 'Local Experiences',
      description: 'Discover local attractions and experiences near your chosen accommodation.'
    },
    {
      icon: <MdOutlinePayments className="service-icon" />,
      title: 'Transparent Pricing',
      description: 'No hidden fees. See the total price upfront before you book.'
    }
  ];

  return (
    <div className="services-page">
      <section className="services-hero">
        <div className="container">
          <h1>Our Services</h1>
          <p>Everything you need for a perfect stay, all in one place</p>
        </div>
      </section>

      <section className="services-section">
        <div className="container">
          <div className="section-header">
            <h2>How We Make Your Stay Better</h2>
            <p className="section-subtitle">Experience the WorthyStay difference with our comprehensive services</p>
          </div>
          <div className="services-grid">
            {services.map((service, index) => (
              <div key={index} className="service-card">
                <div className="service-icon-container">
                  {service.icon}
                </div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container">
          <div className="cta-content">
            <h2>Ready to Find Your Perfect Stay?</h2>
            <p>Join thousands of satisfied travelers who found their ideal accommodation with WorthyStay.</p>
            <div className="cta-buttons">
              <button 
                className="cta-button primary"
                onClick={handleBrowseProperties}
              >
                Browse Properties
              </button>
              <button 
                className="cta-button secondary"
                onClick={handleContactSupport}
              >
                Contact Support
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
