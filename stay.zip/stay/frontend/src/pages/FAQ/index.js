import React, { useState } from 'react';
import { FaChevronDown, FaChevronUp } from 'react-icons/fa';
import './FAQ.css';

const FAQ = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const faqs = [
    {
      question: 'How do I make a reservation?',
      answer: 'You can make a reservation directly through our website by selecting your desired dates and property. Follow the booking process to complete your reservation.'
    },
    {
      question: 'What is the cancellation policy?',
      answer: 'Our standard cancellation policy allows for free cancellation up to 48 hours before check-in. Some properties may have different policies which will be clearly stated during the booking process.'
    },
    {
      question: 'Is there a minimum stay requirement?',
      answer: 'Minimum stay requirements vary by property and season. Most properties require a 2-night minimum stay, especially during peak seasons.'
    },
    {
      question: 'What payment methods do you accept?',
      answer: 'We accept all major credit cards including Visa, MasterCard, American Express, and Discover. Some properties may also accept bank transfers.'
    },
    {
      question: 'Are pets allowed?',
      answer: 'Pet policies vary by property. Please check the property details or contact us for specific information about pet-friendly accommodations.'
    },
    {
      question: 'What time is check-in and check-out?',
      answer: 'Standard check-in time is 3:00 PM and check-out is 11:00 AM. Early check-in and late check-out may be available upon request and subject to availability.'
    },
    {
      question: 'Is parking available?',
      answer: 'Most of our properties offer parking facilities. Please check the property details or contact us for specific parking information.'
    },
    {
      question: 'Do you offer long-term stays?',
      answer: 'Yes, we offer special rates for long-term stays (28 nights or more). Please contact our reservations team for more information and pricing.'
    }
  ];

  const toggleFAQ = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <div className="faq-page">
      <section className="faq-hero">
        <div className="container">
          <h1>Frequently Asked Questions</h1>
          <p>Find answers to common questions about our services and bookings</p>
        </div>
      </section>

      <section className="faq-section">
        <div className="container">
          <div className="faq-container">
            {faqs.map((faq, index) => (
              <div key={index} className="faq-item">
                <div 
                  className="faq-question" 
                  onClick={() => toggleFAQ(index)}
                >
                  <h3>{faq.question}</h3>
                  <span className="faq-icon">
                    {activeIndex === index ? <FaChevronUp /> : <FaChevronDown />}
                  </span>
                </div>
                <div 
                  className={`faq-answer ${activeIndex === index ? 'active' : ''}`}
                >
                  <p>{faq.answer}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="faq-contact">
            <h2>Still have questions?</h2>
            <p>Our team is here to help you with any questions you may have.</p>
            <a href="/contact" className="contact-button">Contact Us</a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default FAQ;
