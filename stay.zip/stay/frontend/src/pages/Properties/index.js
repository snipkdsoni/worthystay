import React, { useState, useEffect } from 'react';
import { FaSearch, FaChevronDown, FaFilter } from 'react-icons/fa';
import PropertyCard from '../../components/PropertyCard';
import './Properties.css';

// Mock data for properties
const mockProperties = [
  // 1-5: Apartments
  {
    id: '1',
    title: 'Luxury 2BHK Apartment in HSR Layout',
    type: 'apartment',
    price: 35000,
    rating: 4.5,
    reviewCount: 128,
    bedrooms: 2,
    bathrooms: 2,
    area: 1200,
    location: 'HSR Layout, Bangalore',
    images: ['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'],
    isVerified: true,
    discount: 10
  },
  {
    id: '2',
    title: 'Modern 1BHK in Indiranagar',
    type: 'apartment',
    price: 28000,
    rating: 4.3,
    reviewCount: 92,
    bedrooms: 1,
    bathrooms: 1,
    area: 750,
    location: 'Indiranagar, Bangalore',
    images: ['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'],
    isVerified: true,
    discount: 5
  },
  {
    id: '3',
    title: 'Spacious 3BHK in Whitefield',
    type: 'apartment',
    price: 45000,
    rating: 4.6,
    reviewCount: 156,
    bedrooms: 3,
    bathrooms: 3,
    area: 1800,
    location: 'Whitefield, Bangalore',
    images: ['https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'],
    isVerified: true,
    discount: 8
  },
  {
    id: '4',
    title: 'Studio Apartment in Andheri East',
    type: 'apartment',
    price: 32000,
    rating: 4.1,
    reviewCount: 67,
    bedrooms: 1,
    bathrooms: 1,
    area: 550,
    location: 'Andheri East, Mumbai',
    images: ['https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80'],
    isVerified: true,
    discount: 5
  },
  {
    id: '5',
    title: 'Premium 2BHK in Banjara Hills',
    type: 'apartment',
    price: 38000,
    rating: 4.7,
    reviewCount: 134,
    bedrooms: 2,
    bathrooms: 2,
    area: 1350,
    location: 'Banjara Hills, Hyderabad',
    images: ['https://images.unsplash.com/photo-1600585152220-90363fe7e115?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'],
    isVerified: true,
    discount: 12
  },
  
  // 6-10: PGs
  {
    id: '6',
    title: 'Cozy PG for Girls in Koramangala',
    type: 'pg',
    price: 12000,
    rating: 4.2,
    reviewCount: 89,
    bedrooms: 1,
    bathrooms: 1,
    area: 400,
    location: 'Koramangala, Bangalore',
    images: ['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'],
    isVerified: true,
    discount: 5
  },
  {
    id: '7',
    title: 'Premium PG for Working Professionals',
    type: 'pg',
    price: 18000,
    rating: 4.6,
    reviewCount: 143,
    bedrooms: 1,
    bathrooms: 1,
    area: 350,
    location: 'Bandra West, Mumbai',
    images: ['https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'],
    isVerified: true,
    discount: 8
  },
  {
    id: '8',
    title: 'Premium PG for Girls in Saket',
    type: 'pg',
    price: 15000,
    rating: 4.4,
    reviewCount: 112,
    bedrooms: 1,
    bathrooms: 1,
    area: 300,
    location: 'Saket, Delhi',
    images: ['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'],
    isVerified: true,
    discount: 0
  },
  {
    id: '9',
    title: 'Luxury PG for Boys in Gachibowli',
    type: 'pg',
    price: 16000,
    rating: 4.3,
    reviewCount: 98,
    bedrooms: 1,
    bathrooms: 1,
    area: 380,
    location: 'Gachibowli, Hyderabad',
    images: ['https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80'],
    isVerified: true,
    discount: 10
  },
  {
    id: '10',
    title: 'Executive PG in Hitech City',
    type: 'pg',
    price: 20000,
    rating: 4.7,
    reviewCount: 167,
    bedrooms: 1,
    bathrooms: 1,
    area: 450,
    location: 'Hitech City, Hyderabad',
    images: ['https://images.unsplash.com/photo-1600585152220-90363fe7e115?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'],
    isVerified: true,
    discount: 15
  },
  
  // 11-15: Villas
  {
    id: '11',
    title: 'Modern 3BHK Villa in Whitefield',
    type: 'villa',
    price: 85000,
    rating: 4.8,
    reviewCount: 64,
    bedrooms: 3,
    bathrooms: 3,
    area: 2800,
    location: 'Whitefield, Bangalore',
    images: ['https://images.unsplash.com/photo-1613490493576-7fde63acd811?ixlib=rb-4.0.3&auto=format&fit=crop&w=1471&q=80'],
    isVerified: true,
    discount: 15
  },
  {
    id: '13',
    title: 'Beachfront 4BHK Villa in Goa',
    type: 'villa',
    price: 150000,
    rating: 4.9,
    reviewCount: 78,
    bedrooms: 4,
    bathrooms: 5,
    area: 5000,
    location: 'Candolim, Goa',
    images: ['https://images.unsplash.com/photo-1613490493576-7fde63acd811?ixlib=rb-4.0.3&auto=format&fit=crop&w=1471&q=80'],
    isVerified: true,
    discount: 25
  },
  {
    id: '14',
    title: 'Modern 3BHK Villa in Yelahanka',
    type: 'villa',
    price: 75000,
    rating: 4.7,
    reviewCount: 89,
    bedrooms: 3,
    bathrooms: 3,
    area: 2600,
    location: 'Yelahanka, Bangalore',
    images: ['https://images.unsplash.com/photo-1600585152220-90363fe7e115?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'],
    isVerified: true,
    discount: 10
  },
  
  // 16-20: Mixed properties
  {
    id: '16',
    title: 'Furnished 2BHK in Marathahalli',
    type: 'apartment',
    price: 32000,
    rating: 4.3,
    reviewCount: 112,
    bedrooms: 2,
    bathrooms: 2,
    area: 1100,
    location: 'Marathahalli, Bangalore',
    images: ['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'],
    isVerified: true,
    discount: 8
  },
  {
    id: '17',
    title: 'Budget PG in Electronic City',
    type: 'pg',
    price: 9000,
    rating: 3.9,
    reviewCount: 67,
    bedrooms: 1,
    bathrooms: 1,
    area: 300,
    location: 'Electronic City, Bangalore',
    images: ['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'],
    isVerified: true,
    discount: 0
  },
  {
    id: '18',
    title: 'Luxury 4BHK Villa in Whitefield',
    type: 'villa',
    price: 110000,
    rating: 4.9,
    reviewCount: 92,
    bedrooms: 4,
    bathrooms: 5,
    area: 4200,
    location: 'Whitefield, Bangalore',
    images: ['https://images.unsplash.com/photo-1613490493576-7fde63acd811?ixlib=rb-4.0.3&auto=format&fit=crop&w=1471&q=80'],
    isVerified: true,
    discount: 18
  },
  {
    id: '19',
    title: 'Modern 1BHK in HSR Layout',
    type: 'apartment',
    price: 28000,
    rating: 4.4,
    reviewCount: 145,
    bedrooms: 1,
    bathrooms: 1,
    area: 700,
    location: 'HSR Layout, Bangalore',
    images: ['https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80'],
    isVerified: true,
    discount: 5
  },
  {
    id: '20',
    title: 'Premium PG in HSR Layout',
    type: 'pg',
    price: 15000,
    rating: 4.5,
    reviewCount: 134,
    bedrooms: 1,
    bathrooms: 1,
    area: 350,
    location: 'HSR Layout, Bangalore',
    images: ['https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80'],
    isVerified: true,
    discount: 10
  }
];

const Properties = () => {
  const [filters, setFilters] = useState({
    search: '',
    type: 'all',
    city: 'all',
    minPrice: '',
    maxPrice: ''
  });
  
  const [filteredProperties, setFilteredProperties] = useState(mockProperties);
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Apply filters when they change
  useEffect(() => {
    let results = [...mockProperties];
    
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      results = results.filter(property => 
        property.title.toLowerCase().includes(searchTerm) ||
        property.location.toLowerCase().includes(searchTerm)
      );
    }
    
    if (filters.type !== 'all') {
      results = results.filter(property => property.type === filters.type);
    }
    
    if (filters.city !== 'all') {
      results = results.filter(property => 
        property.location.toLowerCase().includes(filters.city.toLowerCase())
      );
    }
    
    if (filters.minPrice || filters.maxPrice) {
      const min = filters.minPrice ? parseInt(filters.minPrice) : 0;
      const max = filters.maxPrice ? parseInt(filters.maxPrice) : Number.MAX_SAFE_INTEGER;
      results = results.filter(property => property.price >= min && property.price <= max);
    }
    
    setFilteredProperties(results);
  }, [filters]);

  return (
    <div className="properties-page">
      <div className="container">
        <h1>Find Your Perfect Home</h1>
        
        {/* Search and Filter Bar */}
        <div className="search-filter-bar">
          <div className="search-group">
            <label htmlFor="property-search" className="sr-only">Search properties</label>
            <input
              id="property-search"
              type="text"
              name="property-search"
              placeholder="Search by property or location"
              value={filters.search}
              onChange={(e) => setFilters({...filters, search: e.target.value})}
              aria-label="Search properties by name or location"
            />
            <FaSearch className="search-icon" aria-hidden="true" />
          </div>
          
          <div className="filter-group">
            <label htmlFor="property-type" className="sr-only">Property type</label>
            <select
              id="property-type"
              name="property-type"
              value={filters.type}
              onChange={(e) => setFilters({...filters, type: e.target.value})}
              aria-label="Filter by property type"
            >
              <option value="all">All Types</option>
              <option value="pg">PG/Hostel</option>
              <option value="apartment">Apartment</option>
              <option value="villa">Villa</option>
              <option value="house">House</option>
            </select>
            <FaChevronDown className="select-arrow" aria-hidden="true" />
          </div>
          
          <div className="filter-group">
            <label htmlFor="city-filter" className="sr-only">City</label>
            <select
              id="city-filter"
              name="city"
              value={filters.city}
              onChange={(e) => setFilters({...filters, city: e.target.value})}
              aria-label="Filter by city"
            >
              <option value="all">All Cities</option>
              <option value="bangalore">Bangalore</option>
              <option value="mumbai">Mumbai</option>
              <option value="delhi">Delhi</option>
              <option value="hyderabad">Hyderabad</option>
            </select>
            <FaChevronDown className="select-arrow" aria-hidden="true" />
          </div>
          
          <button 
            type="button"
            className="filter-toggle"
            onClick={() => setIsFilterOpen(!isFilterOpen)}
            aria-expanded={isFilterOpen}
            aria-controls="advanced-filters"
          >
            <FaFilter aria-hidden="true" /> {isFilterOpen ? 'Hide Filters' : 'More Filters'}
          </button>
          
          {isFilterOpen && (
            <div id="advanced-filters" className="advanced-filters">
              <div className="price-range">
                <h4>Price Range (₹/month)</h4>
                <div className="price-inputs">
                  <label htmlFor="min-price" className="sr-only">Minimum price</label>
                  <input
                    id="min-price"
                    type="number"
                    name="minPrice"
                    placeholder="Min"
                    value={filters.minPrice}
                    onChange={(e) => setFilters({...filters, minPrice: e.target.value})}
                    aria-label="Minimum price"
                  />
                  <span>to</span>
                  <label htmlFor="max-price" className="sr-only">Maximum price</label>
                  <input
                    id="max-price"
                    type="number"
                    name="maxPrice"
                    placeholder="Max"
                    value={filters.maxPrice}
                    onChange={(e) => setFilters({...filters, maxPrice: e.target.value})}
                    aria-label="Maximum price"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Results Count */}
        <div className="results-count">
          {filteredProperties.length} properties found
        </div>
        
        {/* Property Listings */}
        <div className="property-grid">
          {filteredProperties.length > 0 ? (
            filteredProperties.map(property => (
              <PropertyCard key={property.id} property={property} />
            ))
          ) : (
            <div className="no-results">
              <h3>No properties found matching your criteria</h3>
              <p>Try adjusting your search or filters</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Properties;
