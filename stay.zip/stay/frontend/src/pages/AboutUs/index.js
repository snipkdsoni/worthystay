import React from 'react';
import './AboutUs.css';

const AboutUs = () => {
  const teamMembers = [
    {
      id: 1,
      name: 'Alex Johnson',
      role: 'CEO & Founder',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
      bio: 'Travel enthusiast with over 10 years of experience in the hospitality industry.'
    },
    {
      id: 2,
      name: 'Maria Garcia',
      role: 'Head of Operations',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop&crop=faces',
      bio: 'Ensuring seamless experiences for both our guests and property owners.'
    },
    {
      id: 3,
      name: 'James Wilson',
      role: 'Customer Success',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces',
      bio: 'Dedicated to making sure every guest has a memorable stay.'
    },
    {
      id: 4,
      name: 'Sarah Chen',
      role: 'Marketing Director',
      image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop&crop=faces',
      bio: 'Bringing the best travel experiences to our community.'
    }
  ];

  return (
    <div className="about-us">
      <section className="about-hero">
        <div className="container">
          <h1>About WorthyStay</h1>
          <p>Your trusted partner in finding the perfect stay</p>
        </div>
      </section>

      <section className="about-content">
        <div className="container">
          <div className="about-grid">
            <div className="about-text">
              <h2>Our Story</h2>
              <p>
                Founded in 2023, WorthyStay was born out of a passion for connecting travelers with exceptional accommodations worldwide. 
                We understand that where you stay can make or break your travel experience.
              </p>
              <p>
                Our mission is to provide a seamless booking experience while ensuring you find accommodations that meet your needs and exceed your expectations.
              </p>
            </div>
            <div className="about-image">
              <img 
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800&h=600&fit=crop" 
                alt="Our team working together"
                className="team-image"
              />
            </div>
          </div>

          <section className="team-section">
            <h2>Meet Our Team</h2>
            <p className="team-subtitle">The passionate people behind WorthyStay</p>
            <div className="team-grid">
              {teamMembers.map(member => (
                <div key={member.id} className="team-member">
                  <div className="team-member-image">
                    <img 
                      src={member.image} 
                      alt={member.name}
                      loading="lazy"
                    />
                  </div>
                  <h3>{member.name}</h3>
                  <p className="role">{member.role}</p>
                  <p className="bio">{member.bio}</p>
                </div>
              ))}
            </div>
          </section>

          <div className="values-section">
            <h2>Our Values</h2>
            <div className="values-grid">
              <div className="value-card">
                <h3>Trust</h3>
                <p>We verify all properties to ensure they meet our high standards of quality and safety.</p>
              </div>
              <div className="value-card">
                <h3>Transparency</h3>
                <p>No hidden fees. What you see is what you pay.</p>
              </div>
              <div className="value-card">
                <h3>Customer First</h3>
                <p>Your satisfaction is our top priority. Our support team is available 24/7.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutUs;
