import React, { useState } from 'react';
import { FaMapMarkerAlt, FaPhone, FaEnvelope, FaClock, FaPaperPlane } from 'react-icons/fa';
import './Contact.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const [formStatus, setFormStatus] = useState({
    submitting: false,
    submitted: false,
    error: null
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormStatus({ submitting: true, submitted: false, error: null });
    
    try {
      // Here you would typically make an API call to your backend
      // For now, we'll simulate a successful submission
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setFormStatus({
        submitting: false,
        submitted: true,
        error: null
      });
      
      // Reset form
      setFormData({
        name: '',
        email: '',
        subject: '',
        message: ''
      });
      
      // Reset success message after 5 seconds
      setTimeout(() => {
        setFormStatus(prev => ({
          ...prev,
          submitted: false
        }));
      }, 5000);
      
    } catch (error) {
      setFormStatus({
        submitting: false,
        submitted: false,
        error: 'Failed to send message. Please try again later.'
      });
    }
  };

  const contactInfo = [
    {
      icon: <FaMapMarkerAlt className="contact-icon" />,
      title: 'Our Location',
      text: '123 Worli Sea Face, Worli, Mumbai, Maharashtra 400018',
      link: 'https://maps.app.goo.gl/example',
      linkText: 'View on Map'
    },
    {
      icon: <FaPhone className="contact-icon" />,
      title: 'Phone Number',
      text: '+91 22 1234 5678',
      link: 'tel:+912212345678',
      linkText: 'Call Now'
    },
    {
      icon: <FaEnvelope className="contact-icon" />,
      title: 'Email Address',
      text: 'info@worthystay.com',
      link: 'mailto:info@worthystay.com',
      linkText: 'Send Email'
    },
    {
      icon: <FaClock className="contact-icon" />,
      title: 'Working Hours',
      text: 'Monday - Friday: 9:00 AM - 6:00 PM\nSaturday: 10:00 AM - 4:00 PM',
      link: '',
      linkText: ''
    }
  ];

  return (
    <div className="contact-page">
      <section className="contact-hero">
        <div className="container">
          <h1>Get In Touch</h1>
          <p>We'd love to hear from you. Send us a message and we'll respond as soon as possible.</p>
        </div>
      </section>

      <section className="contact-section">
        <div className="container">
          <div className="contact-container">
            <div className="contact-info">
              <h2>Contact Information</h2>
              <p>Fill out the form or reach out to us directly using the contact details below.</p>
              
              <div className="info-cards">
                {contactInfo.map((item, index) => (
                  <div key={index} className="info-card">
                    <div className="info-icon">
                      {item.icon}
                    </div>
                    <div className="info-content">
                      <h3>{item.title}</h3>
                      <p>{item.text.split('\n').map((line, i) => (
                        <span key={i}>
                          {line}
                          <br />
                        </span>
                      ))}</p>
                      {item.link && (
                        <a href={item.link} className="info-link">
                          {item.linkText}
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="contact-form-container">
              <h2>Send Us a Message</h2>
              
              {formStatus.submitted && (
                <div className="form-success">
                  Thank you for your message! We'll get back to you soon.
                </div>
              )}
              
              {formStatus.error && (
                <div className="form-error">
                  {formStatus.error}
                </div>
              )}
              
              <form onSubmit={handleSubmit} className="contact-form">
                <div className="form-group">
                  <label htmlFor="name">Your Name *</label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    placeholder="John Doe"
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="email">Email Address *</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    placeholder="your@email.com"
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="subject">Subject *</label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    placeholder="How can we help?"
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="message">Your Message *</label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows="5"
                    placeholder="Type your message here..."
                  ></textarea>
                </div>
                
                <button 
                  type="submit" 
                  className="submit-button"
                  disabled={formStatus.submitting}
                >
                  {formStatus.submitting ? (
                    'Sending...'
                  ) : (
                    <>
                      <FaPaperPlane className="button-icon" />
                      Send Message
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
      
      <section className="map-section">
        <div className="map-container">
          <iframe
            title="Our Mumbai Office Location"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3773.352694515772!2d72.8124563158466!3d18.98121598715658!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7ce6e5f4e6c1b%3A0x6a4d6d9b9a3e3b1f!2sWorli%20Sea%20Face%2C%20Worli%2C%20Mumbai%2C%20Maharashtra%20400018!5e0!3m2!1sen!2sin!4v1620000000000!5m2!1sen!2sin"
            width="100%"
            height="450" 
            style={{ border: 0 }} 
            allowFullScreen="" 
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>
      </section>
    </div>
  );
};

export default Contact;
