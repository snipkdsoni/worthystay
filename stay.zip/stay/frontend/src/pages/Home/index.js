import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  FaSearch, 
  FaMapMarkerAlt, 
  FaStar, 
  FaHeart, 
  FaBed, 
  FaBath, 
  FaRulerCombined,
  FaShieldAlt, 
  FaRegClock, 
  FaRegSmile,
  FaQuoteLeft
} from 'react-icons/fa';
import { IoIosArrowForward } from 'react-icons/io';
import { MdOutlineSecurity } from 'react-icons/md';
import './Home.css';

const Home = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [location, setLocation] = useState('');
  const [propertyType, setPropertyType] = useState('all');
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  const handleSearch = (e) => {
    e.preventDefault();
    
    // Prepare search parameters
    const searchParams = new URLSearchParams();
    
    if (searchTerm) searchParams.append('q', searchTerm);
    if (location) searchParams.append('city', location);
    if (propertyType && propertyType !== 'all') searchParams.append('type', propertyType);
    
    // Navigate to the properties page with search parameters
    window.location.href = `/properties?${searchParams.toString()}`;
  };

  const featuredProperties = [
    { 
      id: 1, 
      title: 'Premium PG for Working Professionals', 
      location: 'Hitech City, Hyderabad', 
      price: 15000, 
      type: 'PG',
      rating: 4.7,
      reviews: 86,
      isFavorite: false,
      image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      amenities: ['AC', 'Food', 'WiFi', 'Laundry'],
      beds: 1,
      baths: 1,
      area: 200
    },
    { 
      id: 2, 
      title: 'Luxury 2BHK Apartment', 
      location: 'Whitefield, Bangalore', 
      price: 35000, 
      type: 'Flat',
      rating: 4.8,
      reviews: 124,
      isFavorite: true,
      image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      amenities: ['Fully Furnished', 'Gym', 'Pool', '24/7 Security'],
      beds: 2,
      baths: 2,
      area: 950
    },
    { 
      id: 3, 
      title: 'Luxury Villa with Private Pool', 
      location: 'Alibaug, Maharashtra', 
      price: 65000, 
      type: 'Villa',
      rating: 4.9,
      reviews: 156,
      isFavorite: false,
      image: 'https://images.unsplash.com/photo-1600585152220-90363fe7e115?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      amenities: ['Private Pool', '4 Beds', 'Garden', 'Parking'],
      beds: 4,
      baths: 4,
      area: 3200
    },
  ];

  const features = [
    { 
      icon: <FaShieldAlt />, 
      title: 'Verified Listings', 
      description: 'Every property is personally verified by our team' 
    },
    { 
      icon: <FaRegClock />, 
      title: 'Quick Search', 
      description: 'Find properties in minutes with our advanced filters' 
    },
    { 
      icon: <FaRegSmile />, 
      title: 'Happy Customers', 
      description: 'Join 10,000+ satisfied renters across India' 
    },
    { 
      icon: <MdOutlineSecurity />, 
      title: 'Secure Payments', 
      description: '100% secure payment processing' 
    }
  ];

  const testimonials = [
    {
      id: 1,
      name: 'Rahul Sharma',
      role: 'Software Engineer, Bangalore',
      content: 'Found my perfect PG in HSR Layout within a day. The process was smooth and the property was exactly as shown in the pictures.',
      rating: 5,
      image: 'https://randomuser.me/api/portraits/men/32.jpg'
    },
    {
      id: 2,
      name: 'Priya Patel',
      role: 'Marketing Executive, Mumbai',
      content: 'The villa I booked through this platform was amazing! Great customer support and transparent pricing. Will definitely use again.',
      rating: 4,
      image: 'https://randomuser.me/api/portraits/women/44.jpg'
    },
    {
      id: 3,
      name: 'Amit Kumar',
      role: 'Student, Delhi',
      content: 'As a student, finding affordable and safe accommodation was tough. This platform made it so easy with verified listings and good filters.',
      rating: 5,
      image: 'https://randomuser.me/api/portraits/men/22.jpg'
    }
  ];

  const toggleFavorite = (id) => {
    // In a real app, this would update the state
    console.log(`Toggled favorite for property ${id}`);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const renderStars = (rating) => {
    return Array(5).fill(0).map((_, i) => (
      <FaStar key={i} className={i < rating ? 'star-icon filled' : 'star-icon'} />
    ));
  };

  return (
    <div className="home">
      {/* Hero Section with Search */}
      <section className="hero">
        <div className="hero-overlay"></div>
        <div className="hero-content">
          <h1>Find Your Perfect Home in India</h1>
          <p className="hero-subtitle">
            Discover and book premium PGs, Flats, and Villas across India's top cities.
            Verified properties with transparent pricing and no hidden charges.
          </p>
          
          {/* Enhanced Search Form */}
          <div className="search-form">
            <div className="form-group search-input">
              <FaSearch className="input-icon" />
              <input 
                type="text" 
                placeholder="Search by area, locality or landmark"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="search-field"
              />
            </div>
            
            <div className="form-group location-select">
              <FaMapMarkerAlt className="input-icon" />
              <select 
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="select-field"
              >
                <option value="">Select City</option>
                <option value="bangalore">Bangalore</option>
                <option value="ahmedabad">Ahmedabad</option>
                <option value="mumbai">Mumbai</option>
                <option value="delhi">Delhi NCR</option>
              </select>
            </div>
            
            <div className="form-group type-select">
              <select 
                value={propertyType}
                onChange={(e) => setPropertyType(e.target.value)}
                className="select-field"
              >
                <option value="all">All Types</option>
                <option value="pg">PG/Co-living</option>
                <option value="flat">Flats/Apartments</option>
                <option value="villa">Villas</option>
              </select>
            </div>
            
            <button 
              className="search-button"
              onClick={handleSearch}
            >
              <FaSearch /> Search
            </button>
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="featured-properties">
        <div className="container">
          <h2>Featured Properties</h2>
          <div className="property-grid">
            {featuredProperties.map((property) => (
              <div key={property.id} className="property-card">
                <div className="property-badge">{property.type}</div>
                <button 
                  className={`favorite-button ${property.isFavorite ? 'active' : ''}`}
                  onClick={() => toggleFavorite(property.id)}
                >
                  <FaHeart />
                </button>
                <div className="property-image">
                  <img src={property.image} alt={property.title} />
                </div>
                <div className="property-details">
                  <h3>{property.title}</h3>
                  <p className="property-location">
                    <FaMapMarkerAlt /> {property.location}
                  </p>
                  <div className="property-features">
                    <span><FaBed /> {property.beds} {property.beds > 1 ? 'Beds' : 'Bed'}</span>
                    <span><FaBath /> {property.baths} {property.baths > 1 ? 'Baths' : 'Bath'}</span>
                    <span><FaRulerCombined /> {property.area} sq.ft</span>
                  </div>
                  <div className="property-amenities">
                    {property.amenities.slice(0, 3).map((amenity, index) => (
                      <span key={index} className="amenity-tag">{amenity}</span>
                    ))}
                    {property.amenities.length > 3 && (
                      <span className="amenity-tag">+{property.amenities.length - 3} more</span>
                    )}
                  </div>
                  <div className="property-footer">
                    <div className="property-rating">
                      <FaStar className="star-icon" />
                      <span>{property.rating}</span>
                      <span className="reviews">({property.reviews} reviews)</span>
                    </div>
                    <div className="property-price">
                      ₹{property.price.toLocaleString('en-IN')}
                      <span>/month</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="view-all">
            <Link to="/properties" className="btn btn-outline">View All Properties</Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="why-choose-us">
        <div className="container">
          <h2>Why Choose Us</h2>
          <p className="section-subtitle">We make finding your perfect home simple and stress-free</p>
          <div className="features-grid">
            {features.map((feature, index) => (
              <div key={index} className="feature-card">
                <div className="feature-icon">{feature.icon}</div>
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="testimonials">
        <div className="container">
          <h2>What Our Customers Say</h2>
          <p className="section-subtitle">Hear from people who found their perfect home with us</p>
          <div className="testimonial-container">
            {testimonials.map((testimonial, index) => (
              <div 
                key={testimonial.id}
                className={`testimonial-card ${index === activeTestimonial ? 'active' : ''}`}
              >
                <div className="testimonial-content">
                  <FaQuoteLeft className="quote-icon" />
                  <p>{testimonial.content}</p>
                  <div className="testimonial-rating">
                    {renderStars(testimonial.rating)}
                  </div>
                </div>
                <div className="testimonial-author">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name} 
                    className="testimonial-avatar"
                  />
                  <div className="author-info">
                    <h4>{testimonial.name}</h4>
                    <p>{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
            <div className="testimonial-dots">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={`dot ${index === activeTestimonial ? 'active' : ''}`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="categories">
        <div className="container">
          <h2>Browse by Category</h2>
          <div className="category-grid">
            <div className="category-card">
              <div className="category-icon">🏠</div>
              <h3>PG/Co-living</h3>
              <p>Fully furnished PGs with all amenities for students and professionals</p>
              <Link to="/properties?type=pg" className="category-link">Explore</Link>
            </div>
            <div className="category-card">
              <div className="category-icon">🏢</div>
              <h3>Flats & Apartments</h3>
              <p>1/2/3 BHK flats with modern amenities in prime locations</p>
              <Link to="/properties?type=flat" className="category-link">Explore</Link>
            </div>
            <div className="category-card">
              <div className="category-icon">🏡</div>
              <h3>Luxury Villas</h3>
              <p>Premium villas with private amenities for a luxurious lifestyle</p>
              <Link to="/properties?type=villa" className="category-link">Explore</Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;