import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FaBed, FaBath, FaRulerCombined, FaWifi, FaParking, FaSwimmingPool, FaUtensils, FaTv, FaStar, FaMapMarkerAlt, FaCalendarAlt, FaUserFriends, FaArrowLeft } from 'react-icons/fa';
import './PropertyDetails.css';

const PropertyDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [checkInDate, setCheckInDate] = useState('');
  const [checkOutDate, setCheckOutDate] = useState('');
  const [guests, setGuests] = useState(1);

  // Generate consistent high-quality property images
  const getPropertyImages = (propertyId) => {
    // Base set of high-quality property images
    const baseImages = [
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1600&q=80',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-1.2.1&auto=format&fit=crop&w=1600&q=80',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1600&q=80',
      'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1600&q=80',
      'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-1.2.1&auto=format&fit=crop&w=1600&q=80',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1600&q=80'
    ];
    
    // Use the property ID to determine which images to show
    const startIndex = (propertyId % (baseImages.length - 3)) || 0;
    return baseImages.slice(startIndex, startIndex + 4);
  };

  // Function to navigate back to properties page
  const handleBackToProperties = () => {
    navigate('/properties');
  };

  useEffect(() => {
    const fetchProperty = async () => {
      try {
        console.log('Fetching property with ID:', id);
        // Simulating API call
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // Mock data matching the Home component's property structure
        const mockProperties = {
          1: { 
            id: 1, 
            title: 'Premium PG for Working Professionals',
            location: 'Hitech City, Hyderabad',
            price: 15000,
            type: 'PG',
            rating: 4.7,
            reviews: 86,
            description: 'A premium PG accommodation for working professionals with modern amenities and a comfortable living space.',
            amenities: ['AC', 'Food', 'WiFi', 'Laundry', 'Housekeeping', 'Power Backup'],
            images: getPropertyImages(1),
            beds: 1,
            baths: 1,
            area: 200,
            maxGuests: 1,
            host: {
              name: 'Rahul Sharma',
              avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
              joined: 'January 2020',
              responseRate: '98%',
              responseTime: 'within an hour',
              contactNumber: '+91 98765 43210'
            },
            rules: [
              'No smoking inside premises',
              'Visitors allowed till 10 PM',
              'No outside food after 11 PM',
              'Check-in after 12:00 PM',
              'Checkout by 11:00 AM'
            ]
          },
          2: { 
            id: 2, 
            title: 'Luxury 2BHK Apartment',
            location: 'Whitefield, Bangalore',
            price: 35000,
            type: 'Flat',
            rating: 4.8,
            reviews: 124,
            description: 'Spacious 2BHK apartment in a prime location with modern amenities and beautiful city views.',
            amenities: ['Fully Furnished', 'Gym', 'Pool', '24/7 Security', 'Power Backup', 'Lift'],
            images: getPropertyImages(2),
            beds: 2,
            baths: 2,
            area: 950,
            maxGuests: 4,
            host: {
              name: 'Priya Patel',
              avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
              joined: 'March 2019',
              responseRate: '99%',
              responseTime: 'within 30 minutes',
              contactNumber: '+91 98765 12345'
            },
            rules: [
              'No smoking',
              'No pets',
              'No parties or events',
              'Check-in after 2:00 PM',
              'Checkout by 11:00 AM'
            ]
          },
          3: { 
            id: 3, 
            title: 'Luxury Villa with Private Pool',
            location: 'Alibaug, Maharashtra',
            price: 65000,
            type: 'Villa',
            rating: 4.9,
            reviews: 156,
            description: 'Experience luxury in this stunning villa with a private pool, beautiful garden, and modern amenities.',
            amenities: ['Private Pool', '4 Beds', 'Garden', 'Parking', 'AC', 'Fully Furnished'],
            images: getPropertyImages(3),
            beds: 4,
            baths: 4,
            area: 3200,
            maxGuests: 8,
            host: {
              name: 'Amit Kumar',
              avatar: 'https://randomuser.me/api/portraits/men/22.jpg',
              joined: 'July 2020',
              responseRate: '97%',
              responseTime: 'within an hour',
              contactNumber: '+91 98765 67890'
            },
            rules: [
              'No smoking inside',
              'Pets allowed with prior approval',
              'No loud music after 10 PM',
              'Check-in after 2:00 PM',
              'Checkout by 11:00 AM'
            ]
          }
        };
        
        console.log('Available properties:', Object.keys(mockProperties).map(k => parseInt(k)));
        
        // Try to find the property by ID
        const propertyId = parseInt(id);
        const foundProperty = mockProperties[propertyId];
        
        if (foundProperty) {
          console.log('Found property:', foundProperty);
          setProperty(foundProperty);
        } else {
          console.log('Property not found, creating with high-quality images');
          const propertyTypes = ['PG', 'Apartment', 'Villa', 'House', 'Studio'];
          const propertyType = propertyTypes[Math.floor(Math.random() * propertyTypes.length)];
          const cities = ['Mumbai', 'Delhi', 'Bangalore', 'Hyderabad', 'Chennai', 'Pune', 'Kolkata', 'Ahmedabad'];
          const randomCity = cities[Math.floor(Math.random() * cities.length)];
          const areas = [500, 650, 800, 1000, 1200, 1500, 1800, 2000];
          const randomArea = areas[Math.floor(Math.random() * areas.length)];
          
          const randomProperty = {
            id: propertyId,
            title: `${propertyType} in ${randomCity}`,
            location: `${randomCity}, India`,
            price: Math.floor(Math.random() * 50000) + 10000,
            type: propertyType,
            rating: (Math.random() * 1 + 4).toFixed(1),
            reviews: Math.floor(Math.random() * 100) + 10,
            description: `A beautiful ${propertyType.toLowerCase()} in ${randomCity} with modern amenities and comfortable living space.`,
            amenities: ['Wifi', 'AC', 'Kitchen', 'TV', 'Laundry', 'Power Backup'],
            images: getPropertyImages(propertyId),
            beds: Math.floor(Math.random() * 4) + 1,
            baths: Math.floor(Math.random() * 3) + 1,
            area: randomArea,
            maxGuests: Math.floor(Math.random() * 6) + 2,
            host: {
              name: 'Host User',
              avatar: `https://randomuser.me/api/portraits/${Math.random() > 0.5 ? 'men' : 'women'}/${Math.floor(Math.random() * 50)}.jpg`,
              joined: new Date(2020, Math.floor(Math.random() * 36)).toLocaleDateString('en-US', { year: 'numeric', month: 'long' }),
              responseRate: `${90 + Math.floor(Math.random() * 10)}%`,
              responseTime: ['within an hour', 'within 30 minutes', 'within a few hours'][Math.floor(Math.random() * 3)],
              contactNumber: `+91 ${Math.floor(7000000000 + Math.random() * 3000000000)}`
            },
            rules: [
              'No smoking',
              'No parties or events',
              'Check-in after 2:00 PM',
              'Checkout by 11:00 AM',
              'Pets allowed with prior approval'
            ]
          };
          console.log('Created property with high-quality images:', randomProperty);
          setProperty(randomProperty);
        }
        setLoading(false);
      } catch (error) {
        console.error('Error fetching property:', error);
        setLoading(false);
      }
    };

    fetchProperty();
  }, [id]);

  useEffect(() => {
    console.log('Property state updated:', property);
    if (property) {
      console.log('Property images:', property.images);
    }
  }, [property]);

  const nextImage = () => {
    setCurrentImageIndex(prev => 
      prev === property.images.length - 1 ? 0 : prev + 1
    );
  };

  const prevImage = () => {
    setCurrentImageIndex(prev => 
      prev === 0 ? property.images.length - 1 : prev - 1
    );
  };

  const handleBooking = (e) => {
    e.preventDefault();
    if (!checkInDate || !checkOutDate) {
      alert('Please select both check-in and check-out dates');
      return;
    }
    alert(`Booking request sent for ${property.title} from ${checkInDate} to ${checkOutDate} for ${guests} guests.`);
  };

  if (loading || !property) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading property details...</p>
      </div>
    );
  }

  return (
    <div className="property-details-page">
      {/* Back to Properties Button */}
      <button 
        className="back-to-properties"
        onClick={handleBackToProperties}
      >
        <FaArrowLeft className="back-icon" /> Back to Properties
      </button>
      
      <div className="property-gallery">
        <div 
          className="main-image"
          style={{ backgroundImage: `url(${property.images[currentImageIndex]})` }}
        >
          <button className="nav-button prev" onClick={prevImage}>&#10094;</button>
          <button className="nav-button next" onClick={nextImage}>&#10095;</button>
          <div className="image-counter">
            {currentImageIndex + 1} / {property.images.length}
          </div>
        </div>
        <div className="thumbnail-container">
          {property.images.map((img, index) => (
            <div 
              key={index} 
              className={`thumbnail ${index === currentImageIndex ? 'active' : ''}`}
              style={{ backgroundImage: `url(${img})` }}
              onClick={() => setCurrentImageIndex(index)}
            />
          ))}
        </div>
      </div>

      <div className="property-content">
        <div className="property-info">
          <h1>{property.title}</h1>
          <div className="property-meta">
            <div className="rating">
              <FaStar className="star-icon" /> {property.rating} 
              <span className="reviews">({property.reviews} reviews)</span>
            </div>
            <div className="location">
              <FaMapMarkerAlt className="location-icon" /> {property.location}
            </div>
          </div>

          <div className="property-highlights">
            <div className="highlight">
              <FaBed className="icon" />
              <span>{property.beds} {property.beds === 1 ? 'bedroom' : 'bedrooms'}</span>
            </div>
            <div className="highlight">
              <FaBath className="icon" />
              <span>{property.baths} {property.baths === 1 ? 'bathroom' : 'bathrooms'}</span>
            </div>
            <div className="highlight">
              <FaRulerCombined className="icon" />
              <span>{property.area} m²</span>
            </div>
            <div className="highlight">
              <FaUserFriends className="icon" />
              <span>Up to {property.maxGuests} guests</span>
            </div>
          </div>

          <div className="property-description">
            <h2>About this property</h2>
            <p>{property.description}</p>
          </div>

          <div className="property-amenities">
            <h2>Amenities</h2>
            <div className="amenities-grid">
              {property.amenities.map((amenity, index) => (
                <div key={index} className="amenity-item">
                  {amenity === 'Wifi' && <FaWifi className="amenity-icon" />}
                  {amenity === 'Pool' && <FaSwimmingPool className="amenity-icon" />}
                  {amenity === 'Kitchen' && <FaUtensils className="amenity-icon" />}
                  {amenity === 'TV' && <FaTv className="amenity-icon" />}
                  {amenity === 'Parking' && <FaParking className="amenity-icon" />}
                  <span>{amenity}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="property-rules">
            <h2>House Rules</h2>
            <ul>
              {property.rules.map((rule, index) => (
                <li key={index}>{rule}</li>
              ))}
            </ul>
          </div>
        </div>

        <div className="booking-widget">
          <div className="price-box">
            <div className="price">${property.price} <span>night</span></div>
            <div className="reviews">
              <FaStar className="star-icon" /> {property.rating} · {property.reviews} reviews
            </div>
          </div>
          
          <form onSubmit={handleBooking} className="booking-form">
            <div className="form-group">
              <label>Check-in</label>
              <div className="input-with-icon">
                <FaCalendarAlt className="input-icon" />
                <input 
                  type="date" 
                  value={checkInDate}
                  onChange={(e) => setCheckInDate(e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                  required 
                />
              </div>
            </div>
            
            <div className="form-group">
              <label>Check-out</label>
              <div className="input-with-icon">
                <FaCalendarAlt className="input-icon" />
                <input 
                  type="date" 
                  value={checkOutDate}
                  onChange={(e) => setCheckOutDate(e.target.value)}
                  min={checkInDate || new Date().toISOString().split('T')[0]}
                  disabled={!checkInDate}
                  required 
                />
              </div>
            </div>
            
            <div className="form-group">
              <label>Guests</label>
              <div className="input-with-icon">
                <FaUserFriends className="input-icon" />
                <select 
                  value={guests} 
                  onChange={(e) => setGuests(parseInt(e.target.value))}
                >
                  {[...Array(property.maxGuests).keys()].map(num => (
                    <option key={num + 1} value={num + 1}>
                      {num + 1} {num === 0 ? 'guest' : 'guests'}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            <button type="submit" className="book-now-btn">Book Now</button>
            
            <div className="price-summary">
              <div className="price-row">
                <span>${property.price} x 1 night</span>
                <span>${property.price}</span>
              </div>
              <div className="price-row total">
                <span>Total</span>
                <span>${property.price}</span>
              </div>
            </div>
          </form>
          
          <div className="host-info">
            <div className="host-header">
              <img src={property.host.avatar} alt={property.host.name} className="host-avatar" />
              <div>
                <h4>Hosted by {property.host.name}</h4>
                <p>Joined in {property.host.joined}</p>
              </div>
            </div>
            <div className="host-meta">
              <div className="meta-item">
                <span className="meta-label">Response rate:</span>
                <span className="meta-value">{property.host.responseRate}</span>
              </div>
              <div className="meta-item">
                <span className="meta-label">Response time:</span>
                <span className="meta-value">{property.host.responseTime}</span>
              </div>
              <div className="meta-item">
                <span className="meta-label">Contact:</span>
                <a href={`tel:${property.host.contactNumber.replace(/\D/g, '')}`} className="contact-number">
                  {property.host.contactNumber}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyDetails;