# WorthyStay Frontend

This is the frontend application for WorthyStay, a property booking platform built with React.js. The application provides a responsive and user-friendly interface for browsing and booking properties.

## Features

- **Property Listings**: Browse available properties with filters and search functionality
- **Property Details**: View detailed information about each property including amenities, rules, and host information
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Interactive UI**: Image galleries, date pickers, and interactive elements for a smooth user experience

## Prerequisites

Before you begin, ensure you have the following installed:

- Node.js (v14 or later)
- npm (v6 or later) or yarn (v1.22 or later)

## Getting Started

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd frontend
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   yarn install
   ```

3. **Set up environment variables**
   Create a `.env` file in the root directory with the following variables:
   ```
   REACT_APP_API_URL=http://localhost:8000/api
   ```

4. **Start the development server**
   ```bash
   npm start
   # or
   yarn start
   ```
   The application will be available at [http://localhost:3000](http://localhost:3000)

## Available Scripts

In the project directory, you can run:

- `npm start` - Runs the app in development mode
- `npm test` - Launches the test runner
- `npm run build` - Builds the app for production to the `build` folder
- `npm run eject` - Ejects from Create React App (use with caution)

## Project Structure

```
frontend/
├── public/               # Static files
│   ├── index.html        # Main HTML template
│   └── images/           # Image assets
├── src/
│   ├── components/       # Reusable components
│   │   └── Layout/       # Main layout component
│   ├── pages/            # Page components
│   │   ├── Home/         # Home page
│   │   ├── Properties/   # Property listings
│   │   └── PropertyDetails/ # Property details page
│   ├── services/         # API services
│   ├── utils/            # Utility functions
│   ├── App.js            # Main App component
│   └── index.js          # Entry point
├── package.json          # Project dependencies and scripts
└── README.md             # Project documentation
```

## Styling

This project uses CSS Modules for styling, with each component having its own CSS file. The styling follows a mobile-first approach with responsive design principles.

## API Integration

The frontend is designed to work with a RESTful API. The base URL for API requests can be configured in the `.env` file.

## Deployment

To create a production build:

```bash
npm run build
# or
yarn build
```

This will create a `build` folder with optimized and minified files ready for deployment to any static file hosting service like Netlify, Vercel, or AWS S3.

## Contributing

1. Fork the repository
2. Create a new branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
