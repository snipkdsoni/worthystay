from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['worthystay']

# List all collections
print("Collections in database:")
print(db.list_collection_names())

# Example: Query a collection
collection_name = input("\nEnter collection name to query (e.g., 'properties', 'bookings'): ")
if collection_name in db.list_collection_names():
    print(f"\nFirst 5 documents in {collection_name}:")
    for doc in db[collection_name].find().limit(5):
        print(doc)
else:
    print(f"Collection '{collection_name}' not found.")